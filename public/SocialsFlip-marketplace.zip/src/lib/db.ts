import bcrypt from "bcryptjs";
import type {
  Category,
  StoreData,
  User,
  Listing,
  Order,
  ChatMessage,
  DealStatus,
} from "./types";
import { DEFAULT_CRYPTO_WALLETS } from "./types";
import { loadRawStore, saveRawStore, persistenceMode } from "./store-backend";

let writeQueue: Promise<unknown> = Promise.resolve();

async function ensureStore(): Promise<StoreData> {
  const existing = await loadRawStore();
  if (existing) return existing;
  const seed = await createSeed();
  await saveRawStore(seed);
  return seed;
}

export { persistenceMode };

async function createSeed(): Promise<StoreData> {
  const adminHash = await bcrypt.hash("admin123", 10);
  const buyerHash = await bcrypt.hash("buyer123", 10);
  const sellerHash = await bcrypt.hash("seller123", 10);
  const now = new Date().toISOString();

  const users: User[] = [
    {
      id: 1,
      email: "admin@socialsflip.com",
      passwordHash: adminHash,
      name: "SocialsFlip Admin",
      role: "admin",
      country: "",
      bio: "Escrow moderator",
      phone: "",
      verified: true,
      rating: 5,
      reviewCount: 0,
      dummy: false,
      official: true,
      joinedAt: now,
      active: true,
      paymentMethods: [],
    },
    {
      id: 2,
      email: "store@socialsflip.com",
      passwordHash: sellerHash,
      name: "SocialsFlip",
      role: "seller",
      country: "",
      bio: "Official SocialsFlip store. Items sold by SocialsFlip are sold and delivered directly by us.",
      phone: "",
      verified: true,
      rating: 5,
      reviewCount: 12,
      dummy: false,
      official: true,
      joinedAt: now,
      active: true,
      paymentMethods: [],
    },
    {
      id: 3,
      email: "buyer@demo.com",
      passwordHash: buyerHash,
      name: "Demo Buyer",
      role: "buyer",
      country: "Pakistan",
      bio: "",
      phone: "",
      verified: false,
      rating: 0,
      reviewCount: 0,
      dummy: false,
      joinedAt: now,
      active: true,
      paymentMethods: [],
    },
  ];

  const listings: Listing[] = [
    {
      id: 10,
      sellerId: 2,
      title: "YouTube Gaming Channel — 85K Subs",
      cat: "youtube",
      niche: "Gaming",
      followers: "85,000",
      monetized: true,
      teaser: "Monetized gaming channel with steady RPM and clean history.",
      privateHandle: "https://youtube.com/@sf-gaming-demo",
      price: 2499,
      desc: "Established gaming channel with consistent views. Full ownership transfer via YouTube Brand Account.",
      img: "",
      status: "approved",
      listed: true,
      createdAt: now,
    },
    {
      id: 11,
      sellerId: 2,
      title: "Instagram Fashion Page — 42K Followers",
      cat: "instagram",
      niche: "Fashion",
      followers: "42,000",
      monetized: false,
      teaser: "Aesthetic fashion page with high engagement from US & EU.",
      privateHandle: "@sf_fashion_demo",
      price: 899,
      desc: "Clean aesthetic feed, ready for brand deals after transfer.",
      img: "",
      status: "approved",
      listed: true,
      createdAt: now,
    },
  ];

  // Pre-seed marketplace with realistic dummy sellers + listings.
  let nid = 100;
  const seedSellers = [
    ["Ayesha Media", "Pakistan"],
    ["Omar Growth Lab", "UAE"],
    ["Nova Social Co", "USA"],
    ["PixelReach Studio", "UK"],
  ] as const;
  const seedTemplates: {
    cat: Category;
    title: string;
    niche: string;
    followers: string;
    price: number;
    monetized: boolean;
  }[] = [
    {
      cat: "youtube",
      title: "YouTube Tech Reviews — Mid Size",
      niche: "Tech",
      followers: "28,500",
      price: 1299,
      monetized: true,
    },
    {
      cat: "tiktok",
      title: "TikTok Viral Clips Account",
      niche: "Entertainment",
      followers: "190,000",
      price: 2100,
      monetized: true,
    },
    {
      cat: "x",
      title: "X News & Trends Account",
      niche: "News",
      followers: "44,000",
      price: 480,
      monetized: false,
    },
  ];

  const dummyHash = await bcrypt.hash("dummy123", 10);
  for (let i = 0; i < seedSellers.length; i++) {
    const sid = nid++;
    const [name, country] = seedSellers[i];
    users.push({
      id: sid,
      email: `dummy.seller.${sid}@socialsflip.local`,
      passwordHash: dummyHash,
      name,
      role: "seller",
      country,
      bio: `${name} sells curated social accounts on SocialsFlip.`,
      phone: "",
      verified: true,
      rating: Number((4 + Math.random()).toFixed(1)),
      reviewCount: 5 + i * 3,
      dummy: true,
      joinedAt: new Date(Date.now() - (60 + i * 40) * 86400000).toISOString(),
      active: true,
      paymentMethods: [],
    });
    for (let j = 0; j < 2; j++) {
      const tpl = seedTemplates[(i + j) % seedTemplates.length];
      const lid = nid++;
      listings.push({
        id: lid,
        sellerId: sid,
        title: `${tpl.title} · ${name.split(" ")[0]}`,
        cat: tpl.cat,
        niche: tpl.niche,
        followers: tpl.followers,
        monetized: tpl.monetized,
        teaser: `${tpl.niche} listing ready for escrow transfer.`,
        privateHandle: `@demo_${tpl.cat}_${lid}`,
        price: tpl.price + i * 50,
        desc: `Demo listing for ${tpl.cat}. Private handle hidden until escrow starts.`,
        img: "",
        status: "approved",
        listed: true,
        createdAt: now,
      });
    }
  }

  return {
    fee: 10,
    settings: {
      fee: 10,
      allowDirectPayToSeller: false,
      autoDetectCrypto: false,
      cryptoWallets: DEFAULT_CRYPTO_WALLETS.map((w) => ({ ...w })),
    },
    nid,
    users,
    applications: [],
    listings,
    orders: [],
    privateRequests: [],
    reviews: [],
    posts: [
      {
        id: 1,
        title: "How SocialsFlip escrow protects buyers",
        body: "Every marketplace order is held in escrow until you confirm delivery. Our admin moderators sit in the deal chat with you and the seller.",
        createdAt: now,
      },
      {
        id: 2,
        title: "USDT TRC20 vs BEP20 — pay on the right network",
        body: "SocialsFlip escrow accepts USDT on Tron (TRC20) and BNB Smart Chain (BEP20) only. Always match the network shown at checkout. Sending on the wrong network can permanently lose funds.",
        createdAt: now,
      },
    ],
  };
}

export async function readStore(): Promise<StoreData> {
  return normalizeStore(await ensureStore());
}

export async function updateStore(
  mutator: (data: StoreData) => void | Promise<void>
): Promise<StoreData> {
  const run = writeQueue.then(async () => {
    const data = normalizeStore(await ensureStore());
    await mutator(data);
    normalizeStore(data);
    await saveRawStore(data);
    return data;
  });
  writeQueue = run.catch(() => undefined);
  return run;
}

export function nextId(data: StoreData): number {
  const id = data.nid++;
  return id;
}

export function publicUser(u: User, includePayMethods = false) {
  return {
    id: u.id,
    email: u.email,
    name: u.name,
    role: u.role,
    country: u.country,
    bio: u.bio,
    phone: u.phone,
    verified: u.verified,
    rating: u.rating,
    reviewCount: u.reviewCount,
    dummy: u.dummy,
    official: !!u.official,
    joinedAt: u.joinedAt,
    active: u.active,
    paymentMethods: includePayMethods
      ? (u.paymentMethods || []).filter((m) => m.enabled)
      : undefined,
  };
}

/** Migrate older store files so new fields always exist. */
export function normalizeStore(data: StoreData): StoreData {
  if (!data.settings) {
    data.settings = {
      fee: data.fee ?? 10,
      allowDirectPayToSeller: false,
      autoDetectCrypto: false,
      cryptoWallets: DEFAULT_CRYPTO_WALLETS.map((w) => ({ ...w })),
    };
  }
  data.settings.allowDirectPayToSeller = false;
  // Keep only TRC20 + BEP20 USDT. Prefer saved address; else platform defaults.
  const prev = data.settings.cryptoWallets || [];
  data.settings.cryptoWallets = DEFAULT_CRYPTO_WALLETS.map((def) => {
    const old =
      prev.find((w) => w.asset === def.asset) ||
      (def.asset === "USDT_BEP20"
        ? prev.find((w) => String(w.asset).includes("BEP") || String(w.asset).includes("BSC"))
        : undefined);
    return {
      ...def,
      address: (old?.address || def.address || "").trim(),
      enabled: old?.enabled ?? true,
    };
  });
  data.fee = data.settings.fee ?? data.fee ?? 10;
  for (const u of data.users) {
    if (!u.paymentMethods) u.paymentMethods = [];
  }
  for (const o of data.orders) {
    o.paymentMode = "escrow_crypto";
    if (o.selectedPayMethodId === undefined) o.selectedPayMethodId = null;
    if (!o.paymentInstructions) o.paymentInstructions = "";
    if (!o.paymentProof) o.paymentProof = "";
  }
  return data;
}

export function matchWalletAsset(coin: string): "USDT_TRC20" | "USDT_BEP20" {
  const c = coin.toUpperCase();
  if (c.includes("BEP") || c.includes("BSC") || c.includes("BNB")) return "USDT_BEP20";
  return "USDT_TRC20";
}

export function publicListing(l: Listing, revealHandle = false) {
  return {
    id: l.id,
    sellerId: l.sellerId,
    title: l.title,
    cat: l.cat,
    niche: l.niche,
    followers: l.followers,
    monetized: l.monetized,
    teaser: l.teaser,
    price: l.price,
    desc: l.desc,
    img: l.img,
    status: l.status,
    listed: l.listed,
    createdAt: l.createdAt,
    privateHandle: revealHandle ? l.privateHandle : null,
    handleHidden: !revealHandle,
  };
}

export function calcTotals(price: number, seller: User, feePct: number) {
  const fee = seller.official ? 0 : Math.round(price * feePct) / 100;
  return { price, fee, total: price + fee };
}

export function addSystemMessage(
  order: Order,
  text: string,
  from: ChatMessage["from"] = "admin"
) {
  order.msgs.push({
    id: Date.now() + Math.floor(Math.random() * 1000),
    from,
    text,
    createdAt: new Date().toISOString(),
  });
}

export function setDealStatus(order: Order, status: DealStatus, note?: string) {
  order.status = status;
  if (status === "credentials_shared" || status === "funds_held") {
    order.handleRevealed = true;
  }
  if (note) addSystemMessage(order, note);
}

export const DUMMY_NAMES = [
  "Ayesha Media",
  "Omar Growth Lab",
  "Nova Social Co",
  "PixelReach Studio",
  "BluePeak Creators",
  "Lumen Digital",
  "Crafted Audience",
  "Summit Socials",
  "Orbit Content Hub",
  "Vera Brand Pages",
];

export const DUMMY_LISTING_TEMPLATES: {
  cat: Category;
  title: string;
  niche: string;
  followers: string;
  price: number;
  monetized: boolean;
}[] = [
  {
    cat: "youtube",
    title: "YouTube Tech Reviews — Mid Size",
    niche: "Tech",
    followers: "28,500",
    price: 1299,
    monetized: true,
  },
  {
    cat: "instagram",
    title: "Instagram Lifestyle Page",
    niche: "Lifestyle",
    followers: "61,200",
    price: 750,
    monetized: false,
  },
  {
    cat: "tiktok",
    title: "TikTok Viral Clips Account",
    niche: "Entertainment",
    followers: "190,000",
    price: 2100,
    monetized: true,
  },
  {
    cat: "x",
    title: "X News & Trends Account",
    niche: "News",
    followers: "44,000",
    price: 480,
    monetized: false,
  },
  {
    cat: "other",
    title: "Social Growth Service Pack",
    niche: "Services",
    followers: "N/A",
    price: 199,
    monetized: false,
  },
];
