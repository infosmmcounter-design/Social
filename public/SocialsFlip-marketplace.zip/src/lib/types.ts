export type Role = "buyer" | "seller" | "admin";

export type ListingStatus = "pending" | "approved" | "draft" | "rejected";

export type DealStatus =
  | "awaiting_payment"
  | "funds_held"
  | "credentials_shared"
  | "completed"
  | "disputed"
  | "cancelled"
  | "refunded";

export type MessageRole = "buyer" | "seller" | "admin";

export type PrivateRequestStatus = "none" | "requested" | "approved" | "denied";

export type PaymentMode = "escrow_crypto";

/** Only USDT on Tron (TRC20) and BNB Smart Chain (BEP20). */
export type CryptoAsset = "USDT_TRC20" | "USDT_BEP20";

export interface CryptoWallet {
  asset: CryptoAsset;
  address: string;
  label: string;
  network: string;
  enabled: boolean;
}

export interface SellerPaymentMethod {
  id: string;
  type: string;
  label: string;
  details: string;
  enabled: boolean;
}

export interface PlatformSettings {
  fee: number;
  cryptoWallets: CryptoWallet[];
  allowDirectPayToSeller: boolean;
  autoDetectCrypto: boolean;
}

export const DEFAULT_CRYPTO_WALLETS: CryptoWallet[] = [
  {
    asset: "USDT_TRC20",
    address: "TLj1Esv4stWJNcimvXZDXkP5W9FZfQVpx7",
    label: "USDT (TRC20)",
    network: "Tron",
    enabled: true,
  },
  {
    asset: "USDT_BEP20",
    address: "0x97ff787aa462141bc27660BFDB8b96728B3e0209",
    label: "USDT (BEP20)",
    network: "BNB Smart Chain",
    enabled: true,
  },
];

export const CRYPTO_COIN_OPTIONS = [
  { value: "USDT (TRC20)", asset: "USDT_TRC20" as CryptoAsset },
  { value: "USDT (BEP20)", asset: "USDT_BEP20" as CryptoAsset },
];

export type Category =
  | "youtube"
  | "facebook"
  | "tiktok"
  | "instagram"
  | "x"
  | "ai"
  | "other";

export interface User {
  id: number;
  email: string;
  passwordHash: string;
  name: string;
  role: Role;
  country: string;
  bio: string;
  phone: string;
  verified: boolean;
  rating: number;
  reviewCount: number;
  dummy: boolean;
  official?: boolean;
  joinedAt: string;
  active: boolean;
  paymentMethods: SellerPaymentMethod[];
}

export interface SellerApplication {
  id: number;
  name: string;
  email: string;
  phone: string;
  country: string;
  about: string;
  title: string;
  cat: Category;
  price: number;
  desc: string;
  status: "new" | "approved" | "rejected";
  createdAt: string;
}

export interface Listing {
  id: number;
  sellerId: number;
  title: string;
  cat: Category;
  niche: string;
  followers: string;
  monetized: boolean;
  teaser: string;
  privateHandle: string;
  price: number;
  desc: string;
  img: string;
  status: ListingStatus;
  listed: boolean;
  createdAt: string;
}

export interface ChatMessage {
  id: number;
  from: MessageRole;
  text: string;
  createdAt: string;
}

export interface Order {
  id: number;
  listingId: number;
  sellerId: number;
  buyerId: number | null;
  buyerEmail: string;
  buyerName: string;
  title: string;
  det: string;
  coin: string;
  paymentMode: PaymentMode;
  selectedPayMethodId: string | null;
  paymentInstructions: string;
  paymentProof: string;
  price: number;
  fee: number;
  total: number;
  status: DealStatus;
  handleRevealed: boolean;
  privateRequestStatus: PrivateRequestStatus;
  msgs: ChatMessage[];
  createdAt: string;
}

export interface PrivateRequest {
  id: number;
  listingId: number;
  buyerEmail: string;
  buyerName: string;
  status: "requested" | "approved" | "denied";
  createdAt: string;
}

export interface Review {
  id: number;
  orderId: number;
  listingId: number;
  sellerId: number;
  stars: number;
  text: string;
  who: string;
  date: string;
}

export interface BlogPost {
  id: number;
  title: string;
  body: string;
  createdAt: string;
}

export interface StoreData {
  fee: number;
  settings: PlatformSettings;
  nid: number;
  users: User[];
  applications: SellerApplication[];
  listings: Listing[];
  orders: Order[];
  privateRequests: PrivateRequest[];
  reviews: Review[];
  posts: BlogPost[];
}

export const CATEGORIES: [Category, string][] = [
  ["youtube", "YouTube"],
  ["facebook", "Facebook"],
  ["tiktok", "TikTok"],
  ["instagram", "Instagram"],
  ["x", "X (Twitter)"],
  ["ai", "AI Tools"],
  ["other", "Subscriptions & Other Services"],
];

export const DEAL_STATUS_LABEL: Record<DealStatus, string> = {
  awaiting_payment: "Awaiting Payment",
  funds_held: "Funds Held in Escrow",
  credentials_shared: "Account Credentials Shared",
  completed: "Completed",
  disputed: "Disputed",
  cancelled: "Cancelled",
  refunded: "Refunded",
};

export const DEAL_FLOW: DealStatus[] = [
  "awaiting_payment",
  "funds_held",
  "credentials_shared",
  "completed",
];
