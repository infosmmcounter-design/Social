import type { Metadata } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import { AuthProvider } from "@/components/AuthProvider";
import { StoreHeader } from "@/components/StoreHeader";
import { BottomNav } from "@/components/BottomNav";
import "./globals.css";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "SocialsFlip: Buy Social Media Accounts, Services and Tools",
  description:
    "A marketplace where you can buy social media accounts, services and tools. Marketplace orders are protected by escrow until you confirm delivery.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className={jakarta.className}>
        <AuthProvider>
          <StoreHeader />
          <main className="w page-pad">{children}</main>
          <BottomNav />
        </AuthProvider>
      </body>
    </html>
  );
}
