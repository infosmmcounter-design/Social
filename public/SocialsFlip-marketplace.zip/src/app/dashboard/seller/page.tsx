"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import { api } from "@/lib/api";
import { money } from "@/lib/constants";
import { CATEGORIES, DEAL_STATUS_LABEL, type DealStatus } from "@/lib/types";

export default function SellerDashboard() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [listings, setListings] = useState<
    {
      id: number;
      title: string;
      price: number;
      status: string;
      listed: boolean;
      cat: string;
    }[]
  >([]);
  const [orders, setOrders] = useState<
    { id: number; title: string; total: number; status: DealStatus }[]
  >([]);
  const [requests, setRequests] = useState<
    { id: number; listingId: number; buyerEmail: string; status: string }[]
  >([]);
  const [form, setForm] = useState({
    title: "",
    cat: "youtube",
    niche: "",
    followers: "",
    monetized: false,
    teaser: "",
    privateHandle: "",
    price: "",
    desc: "",
  });
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (!loading && (!user || (user.role !== "seller" && user.role !== "admin"))) {
      router.push("/auth/login");
    }
  }, [user, loading, router]);

  async function refresh() {
    const [l, o, r] = await Promise.all([
      api<{ listings: typeof listings }>("/api/listings?mine=1"),
      api<{ orders: typeof orders }>("/api/orders?scope=seller"),
      api<{ requests: typeof requests }>("/api/private-requests"),
    ]);
    setListings(l.listings);
    setOrders(o.orders);
    setRequests(r.requests);
  }

  useEffect(() => {
    if (user) refresh().catch(() => {});
  }, [user]);

  async function createListing(e: React.FormEvent) {
    e.preventDefault();
    setMsg("");
    try {
      await api("/api/listings", {
        method: "POST",
        json: { ...form, price: Number(form.price) },
      });
      setMsg("Listing submitted for admin approval.");
      setForm({
        title: "",
        cat: "youtube",
        niche: "",
        followers: "",
        monetized: false,
        teaser: "",
        privateHandle: "",
        price: "",
        desc: "",
      });
      await refresh();
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Failed");
    }
  }

  if (loading || !user) return <p className="sec mut">Loading…</p>;

  return (
    <section className="sec">
      <h1 style={{ fontSize: "2rem" }}>Seller dashboard</h1>
      <p className="mut">Manage listings, private requests, deals, and pay methods.</p>

      <h2>Post a listing</h2>
      <form className="card" onSubmit={createListing}>
        <label>Title</label>
        <input
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          required
        />
        <label>Platform</label>
        <select
          value={form.cat}
          onChange={(e) => setForm({ ...form, cat: e.target.value })}
        >
          {CATEGORIES.map(([k, n]) => (
            <option key={k} value={k}>
              {n}
            </option>
          ))}
        </select>
        <label>Niche</label>
        <input
          value={form.niche}
          onChange={(e) => setForm({ ...form, niche: e.target.value })}
        />
        <label>Followers / subscribers</label>
        <input
          value={form.followers}
          onChange={(e) => setForm({ ...form, followers: e.target.value })}
        />
        <label>
          <input
            type="checkbox"
            checked={form.monetized}
            onChange={(e) => setForm({ ...form, monetized: e.target.checked })}
            style={{ width: "auto", marginRight: 8 }}
          />
          Monetized
        </label>
        <label>Teaser description</label>
        <textarea
          rows={2}
          value={form.teaser}
          onChange={(e) => setForm({ ...form, teaser: e.target.value })}
        />
        <label>Private handle / URL (hidden publicly)</label>
        <input
          value={form.privateHandle}
          onChange={(e) => setForm({ ...form, privateHandle: e.target.value })}
          required
        />
        <label>Price (USD)</label>
        <input
          type="number"
          value={form.price}
          onChange={(e) => setForm({ ...form, price: e.target.value })}
          required
        />
        <label>Full description</label>
        <textarea
          rows={3}
          value={form.desc}
          onChange={(e) => setForm({ ...form, desc: e.target.value })}
        />
        <button className="btn" type="submit">
          Submit for approval
        </button>
        {msg ? <p className="okmsg">{msg}</p> : null}
      </form>

      <p className="note sm">
        Payments are crypto-only (USDT TRC20 / BEP20) into SocialsFlip escrow.
        Buyers do not pay you via local methods.
      </p>

      <h2 style={{ marginTop: 24 }}>Your listings</h2>
      <div className="tbl">
        <table>
          <thead>
            <tr>
              <th>Title</th>
              <th>Price</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {listings.map((l) => (
              <tr key={l.id}>
                <td>
                  <Link href={`/listing/${l.id}`}>{l.title}</Link>
                </td>
                <td>{money(l.price)}</td>
                <td>
                  <span className={`pill ${l.listed ? "g" : "w"}`}>
                    {l.status}
                    {l.listed ? " · live" : ""}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h2 style={{ marginTop: 24 }}>Private detail requests</h2>
      <div className="tbl">
        <table>
          <thead>
            <tr>
              <th>Buyer</th>
              <th>Listing</th>
              <th>Status</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {requests.map((r) => (
              <tr key={r.id}>
                <td>{r.buyerEmail}</td>
                <td>#{r.listingId}</td>
                <td>{r.status}</td>
                <td>
                  {r.status === "requested" ? (
                    <>
                      <button
                        className="btn s"
                        onClick={async () => {
                          await api("/api/private-requests", {
                            method: "PATCH",
                            json: { id: r.id, approve: true },
                          });
                          refresh();
                        }}
                      >
                        Approve
                      </button>{" "}
                      <button
                        className="btn s o"
                        onClick={async () => {
                          await api("/api/private-requests", {
                            method: "PATCH",
                            json: { id: r.id, approve: false },
                          });
                          refresh();
                        }}
                      >
                        Deny
                      </button>
                    </>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!requests.length ? <p className="mut">No requests.</p> : null}
      </div>

      <h2 style={{ marginTop: 24 }}>Deals</h2>
      <div className="tbl">
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Item</th>
              <th>Status</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id}>
                <td>{o.id}</td>
                <td>{o.title}</td>
                <td>{DEAL_STATUS_LABEL[o.status]}</td>
                <td>
                  <Link className="btn s o" href={`/deal/${o.id}`}>
                    Chat
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
