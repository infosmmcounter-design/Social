"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { CatIcon } from "@/components/Icons";
import { api } from "@/lib/api";
import { money, stars } from "@/lib/constants";
import { CATEGORIES } from "@/lib/types";
import { useAuth } from "@/components/AuthProvider";

export default function ListingDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const router = useRouter();
  const [data, setData] = useState<{
    listing: Record<string, unknown>;
    seller: Record<string, unknown> | null;
    reviews: { stars: number; who: string; date: string; text: string }[];
  } | null>(null);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [det, setDet] = useState("");
  const [coin, setCoin] = useState("USDT (TRC20)");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (user) {
      setEmail(user.email);
      setName(user.name);
    }
  }, [user]);

  useEffect(() => {
    api<{
      listing: Record<string, unknown>;
      seller: Record<string, unknown> | null;
      reviews: { stars: number; who: string; date: string; text: string }[];
    }>(`/api/listings/${id}`)
      .then(setData)
      .catch(() => setData(null));
  }, [id]);

  if (!data) return <p className="sec mut">Loading listing…</p>;
  const l = data.listing as {
    id: number;
    title: string;
    cat: string;
    price: number;
    desc: string;
    teaser: string;
    niche: string;
    followers: string;
    monetized: boolean;
    img?: string;
    privateHandle: string | null;
    handleHidden: boolean;
    sellerId: number;
  };
  const s = data.seller as {
    id: number;
    name: string;
    country: string;
    bio: string;
    official?: boolean;
    verified?: boolean;
    rating?: number;
    reviewCount?: number;
  } | null;

  const fee = s?.official ? 0 : Math.round(l.price * 10) / 100;
  const total = l.price + fee;
  const catName = CATEGORIES.find((c) => c[0] === l.cat)?.[1] || l.cat;

  async function startDeal() {
    setErr("");
    setBusy(true);
    try {
      const res = await api<{ order: { id: number } }>("/api/orders", {
        method: "POST",
        json: {
          listingId: l.id,
          email,
          name,
          det,
          coin,
          paymentMode: "escrow_crypto",
        },
      });
      router.push(`/deal/${res.order.id}?email=${encodeURIComponent(email)}`);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
    } finally {
      setBusy(false);
    }
  }

  async function requestPrivate() {
    setErr("");
    try {
      await api("/api/private-requests", {
        method: "POST",
        json: { listingId: l.id, email, name },
      });
      alert("Private details request sent. Seller/Admin will approve.");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed");
    }
  }

  return (
    <section className="sec">
      <Link className="mut sm" href={`/listings?cat=${l.cat}`}>
        Back to {catName}
      </Link>
      <div
        className="grid"
        style={{
          gridTemplateColumns: "repeat(auto-fit,minmax(290px,1fr))",
          marginTop: 12,
          alignItems: "start",
        }}
      >
        <div>
          {l.img ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={l.img}
              alt=""
              style={{ width: "100%", borderRadius: 12, marginBottom: 12 }}
            />
          ) : null}
          <span
            className="pill"
            style={{ display: "inline-flex", gap: 5, alignItems: "center" }}
          >
            <CatIcon cat={l.cat} size={14} />
            {catName}
          </span>
          <h1 style={{ fontSize: "1.8rem", marginTop: 8 }}>{l.title}</h1>
          <p className="sm mut">
            {l.niche ? `${l.niche} · ` : ""}
            {l.followers || "—"} · {l.monetized ? "Monetized" : "Not monetized"}
          </p>
          <p style={{ whiteSpace: "pre-wrap" }}>{l.desc || l.teaser}</p>
          <div className="note sm">
            <b>Private handle:</b>{" "}
            {l.handleHidden
              ? "Hidden until escrow deal starts or seller/admin approves your request."
              : l.privateHandle}
          </div>
          {l.handleHidden ? (
            <button className="btn o s" onClick={requestPrivate}>
              Request private details
            </button>
          ) : null}
          <div className="card f" style={{ marginTop: 14 }}>
            <h3>
              {s?.official ? "Sold directly by SocialsFlip" : s?.name}
              {s?.verified ? " · Verified" : ""}
            </h3>
            <p className="sm mut">
              {s?.country}{" "}
              {s?.reviewCount
                ? `· ${stars(s.rating || 0)} ${(s.rating || 0).toFixed(1)} (${s.reviewCount})`
                : ""}
            </p>
            <p className="sm">{s?.bio}</p>
            {s ? (
              <Link className="btn s o" href={`/seller/${s.id}`}>
                View seller profile
              </Link>
            ) : null}
          </div>
        </div>

        <div className="card">
          <h2>Start Escrow Deal</h2>
          <p className="sm mut">
            Guests can buy without an account. A 3-way chat opens with Buyer,
            Seller, and Admin.
          </p>
          <label>Your name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} />
          <label>Your email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
          />
          <label>Transfer details / notes</label>
          <input
            value={det}
            onChange={(e) => setDet(e.target.value)}
            placeholder="Email to receive ownership"
          />

          <label>Pay with (crypto only)</label>
          <select value={coin} onChange={(e) => setCoin(e.target.value)}>
            <option value="USDT (TRC20)">USDT (TRC20) — Tron</option>
            <option value="USDT (BEP20)">USDT (BEP20) — BNB Smart Chain</option>
          </select>
          <p className="sm mut">
            Send USDT only on the network you select. Wrong network can lose
            funds. Admin confirms payment in escrow chat.
          </p>

          <div className="sum" style={{ marginTop: 12 }}>
            <div>
              <span>Product price</span>
              <span>{money(l.price)}</span>
            </div>
            {!s?.official ? (
              <div>
                <span>Escrow fee (10%)</span>
                <span>{money(fee)}</span>
              </div>
            ) : null}
            <div className="t">
              <span>Total</span>
              <span>{money(total)}</span>
            </div>
          </div>
          {err ? <p className="err">{err}</p> : null}
          <button
            className="btn"
            style={{ width: "100%", marginTop: 10 }}
            disabled={busy}
            onClick={startDeal}
          >
            {busy ? "Opening deal…" : "Buy Now / Start Escrow Deal"}
          </button>
        </div>
      </div>

      <h2 style={{ marginTop: 30 }}>Buyer reviews</h2>
      {data.reviews.map((r, i) => (
        <div className="card" key={i} style={{ marginBottom: 10 }}>
          <span className="star">{stars(r.stars)}</span>{" "}
          <span className="sm mut">
            {r.who} · {r.date}
          </span>
          <p style={{ margin: "6px 0 0" }}>{r.text}</p>
        </div>
      ))}
      {!data.reviews.length ? <p className="mut">No reviews yet.</p> : null}
    </section>
  );
}
