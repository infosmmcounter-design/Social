"use client";

import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { ListingCard } from "@/components/ListingCard";
import { api } from "@/lib/api";
import { CATEGORIES } from "@/lib/types";
import { Suspense } from "react";

type Listing = {
  id: number;
  title: string;
  cat: string;
  price: number;
  img?: string;
  followers?: string;
  monetized?: boolean;
  seller?: {
    name: string;
    country?: string;
    official?: boolean;
    verified?: boolean;
    rating?: number;
    reviewCount?: number;
  } | null;
};

function ListingsInner() {
  const sp = useSearchParams();
  const [listings, setListings] = useState<Listing[]>([]);
  const [q, setQ] = useState(sp.get("q") || "");
  const [cat, setCat] = useState(sp.get("cat") || "");
  const [sort, setSort] = useState("newest");

  useEffect(() => {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (cat) params.set("cat", cat);
    if (sort) params.set("sort", sort);
    api<{ listings: Listing[] }>(`/api/listings?${params}`)
      .then((d) => setListings(d.listings))
      .catch(() => setListings([]));
  }, [q, cat, sort]);

  const title = useMemo(() => {
    if (cat) return CATEGORIES.find((c) => c[0] === cat)?.[1] || "Listings";
    return "All listings";
  }, [cat]);

  return (
    <section className="sec">
      <h1 style={{ fontSize: "1.8rem" }}>{title}</h1>
      <div className="row" style={{ flexWrap: "nowrap" }}>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search by service title"
          aria-label="Search"
        />
        <select
          value={cat}
          onChange={(e) => setCat(e.target.value)}
          aria-label="Platform"
          style={{ width: "auto" }}
        >
          <option value="">All platforms</option>
          {CATEGORIES.map(([k, n]) => (
            <option key={k} value={k}>
              {n}
            </option>
          ))}
        </select>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          aria-label="Sort"
          style={{ width: "auto" }}
        >
          <option value="newest">Newest</option>
          <option value="price_asc">Price ↑</option>
          <option value="price_desc">Price ↓</option>
        </select>
      </div>
      <div className="grid" style={{ marginTop: 14 }}>
        {listings.map((l) => (
          <ListingCard key={l.id} listing={l} />
        ))}
        {!listings.length ? (
          <p className="mut">No listings match your search.</p>
        ) : null}
      </div>
    </section>
  );
}

export default function ListingsPage() {
  return (
    <Suspense fallback={<p className="sec mut">Loading…</p>}>
      <ListingsInner />
    </Suspense>
  );
}
