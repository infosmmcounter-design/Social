import { NextResponse } from "next/server";
import { readStore, updateStore, publicUser } from "@/lib/db";
import { requireUser } from "@/lib/auth";

export async function GET() {
  const auth = await requireUser(["admin"]);
  if (auth.error) return NextResponse.json({ error: auth.error }, { status: auth.status });
  const store = await readStore();
  const sellers = store.users.filter(
    (u) => (u.role === "seller" || u.official) && u.active
  );
  return NextResponse.json({
    sellers: sellers.map((s) => ({
      ...publicUser(s, true),
      listingCount: store.listings.filter((l) => l.sellerId === s.id).length,
    })),
  });
}

export async function DELETE(req: Request) {
  const auth = await requireUser(["admin"]);
  if (auth.error) return NextResponse.json({ error: auth.error }, { status: auth.status });
  const body = await req.json();
  const id = Number(body.id);

  await updateStore((data) => {
    const s = data.users.find((u) => u.id === id);
    if (!s || s.official) throw new Error("Cannot remove this seller");
    s.active = false;
    data.listings = data.listings.filter((l) => l.sellerId !== id);
  });

  return NextResponse.json({ ok: true });
}
