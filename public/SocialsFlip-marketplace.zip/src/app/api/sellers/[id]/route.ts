import { NextResponse } from "next/server";
import { readStore, publicUser, publicListing } from "@/lib/db";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const store = await readStore();
  const seller = store.users.find(
    (u) => u.id === Number(id) && (u.role === "seller" || u.official)
  );
  if (!seller || !seller.active)
    return NextResponse.json({ error: "Seller not found" }, { status: 404 });

  const listings = store.listings.filter(
    (l) => l.sellerId === seller.id && l.listed && l.status === "approved"
  );
  const reviews = store.reviews.filter((r) => r.sellerId === seller.id);

  return NextResponse.json({
    seller: publicUser(seller),
    listings: listings.map((l) => publicListing(l, false)),
    reviews,
  });
}
