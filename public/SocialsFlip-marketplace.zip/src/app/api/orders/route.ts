import { NextResponse } from "next/server";
import {
  readStore,
  updateStore,
  nextId,
  calcTotals,
  addSystemMessage,
  publicUser,
  matchWalletAsset,
} from "@/lib/db";
import { getCurrentUser, requireUser } from "@/lib/auth";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const email = (searchParams.get("email") || "").toLowerCase();
  const id = searchParams.get("id");
  const scope = searchParams.get("scope") || "mine";

  const store = await readStore();
  const user = await getCurrentUser();

  if (id) {
    const order = store.orders.find((o) => o.id === Number(id));
    if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });
    const canView =
      (user &&
        (user.role === "admin" ||
          user.id === order.buyerId ||
          user.id === order.sellerId ||
          order.buyerEmail.toLowerCase() === user.email.toLowerCase())) ||
      (email && order.buyerEmail.toLowerCase() === email);
    if (!canView)
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const listing = store.listings.find((l) => l.id === order.listingId);
    const seller = store.users.find((u) => u.id === order.sellerId);
    return NextResponse.json({
      order: {
        ...order,
        privateHandle:
          order.handleRevealed && listing ? listing.privateHandle : null,
      },
      seller: seller ? publicUser(seller, true) : null,
      listing,
      wallets: store.settings.cryptoWallets.filter((w) => w.enabled && w.address),
    });
  }

  let orders = store.orders;
  if (scope === "admin") {
    const auth = await requireUser(["admin"]);
    if (auth.error) return NextResponse.json({ error: auth.error }, { status: auth.status });
  } else if (scope === "seller") {
    const auth = await requireUser(["seller", "admin"]);
    if (auth.error || !auth.user)
      return NextResponse.json({ error: auth.error }, { status: auth.status });
    if (auth.user.role !== "admin") {
      orders = orders.filter((o) => o.sellerId === auth.user!.id);
    }
  } else if (email) {
    orders = orders.filter((o) => o.buyerEmail.toLowerCase() === email);
  } else if (user) {
    orders = orders.filter(
      (o) =>
        o.buyerId === user.id ||
        o.buyerEmail.toLowerCase() === user.email.toLowerCase() ||
        (user.role === "seller" && o.sellerId === user.id) ||
        user.role === "admin"
    );
  } else {
    return NextResponse.json({ orders: [] });
  }

  return NextResponse.json({
    orders: [...orders].sort((a, b) => b.id - a.id),
  });
}

export async function POST(req: Request) {
  const body = await req.json();
  const listingId = Number(body.listingId);
  const buyerEmail = String(body.email || "")
    .trim()
    .toLowerCase();
  const buyerName = String(body.name || "Guest Buyer").trim();
  const det = String(body.det || "").trim();
  const coin = String(body.coin || "USDT (TRC20)");

  if (!listingId || !buyerEmail || !det) {
    return NextResponse.json(
      { error: "Email, transfer details and listing are required." },
      { status: 400 }
    );
  }

  if (!/USDT\s*\((TRC20|BEP20)\)/i.test(coin)) {
    return NextResponse.json(
      { error: "Only USDT TRC20 or USDT BEP20 is accepted." },
      { status: 400 }
    );
  }

  const user = await getCurrentUser();
  let orderId = 0;

  try {
    await updateStore((data) => {
      const listing = data.listings.find(
        (l) => l.id === listingId && l.listed && l.status === "approved"
      );
      if (!listing) throw new Error("Listing not available.");
      const seller = data.users.find((u) => u.id === listing.sellerId);
      if (!seller) throw new Error("Seller not found.");

      const totals = calcTotals(listing.price, seller, data.fee);
      const asset = matchWalletAsset(coin);
      const wallet = data.settings.cryptoWallets.find(
        (w) => w.enabled && w.asset === asset
      );

      const paymentInstructions = wallet?.address
        ? `Send exactly ${totals.total.toFixed(2)} USDT via ${coin} to SocialsFlip escrow wallet (${wallet.network}): ${wallet.address}. Wrong network = lost funds.`
        : `Pay ${totals.total.toFixed(2)} USDT via ${coin}. Escrow wallet address will appear once admin pastes it in Settings (or shares it in this chat).`;

      orderId = nextId(data);
      const order = {
        id: orderId,
        listingId: listing.id,
        sellerId: listing.sellerId,
        buyerId: user?.id ?? null,
        buyerEmail,
        buyerName: buyerName || user?.name || "Guest Buyer",
        title: listing.title,
        det,
        coin,
        paymentMode: "escrow_crypto" as const,
        selectedPayMethodId: null,
        paymentInstructions,
        paymentProof: "",
        price: totals.price,
        fee: totals.fee,
        total: totals.total,
        status: "awaiting_payment" as const,
        handleRevealed: false,
        privateRequestStatus: "none" as const,
        msgs: [],
        createdAt: new Date().toISOString(),
      };

      addSystemMessage(
        order,
        `Escrow deal #${orderId} opened. Buyer, Seller, and Admin (Escrow Moderator) are in this 3-way chat. Status: Awaiting Payment.`
      );
      addSystemMessage(order, `Payment mode: Escrow Crypto only. ${paymentInstructions}`);

      data.orders.push(order);
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Could not create order" },
      { status: 400 }
    );
  }

  const store = await readStore();
  return NextResponse.json({ order: store.orders.find((o) => o.id === orderId) });
}
