import { NextResponse } from "next/server";
import { updateStore, readStore, setDealStatus, addSystemMessage } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import type { DealStatus } from "@/lib/types";
import { DEAL_STATUS_LABEL } from "@/lib/types";

const BUYER_ACTIONS: DealStatus[] = ["completed", "disputed"];
const SELLER_ACTIONS: DealStatus[] = ["credentials_shared"];
const ADMIN_ACTIONS: DealStatus[] = [
  "funds_held",
  "credentials_shared",
  "completed",
  "disputed",
  "cancelled",
  "refunded",
];

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json();
  const status = body.status as DealStatus;
  const note = String(body.note || "").trim();

  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    await updateStore((data) => {
      const order = data.orders.find((o) => o.id === Number(id));
      if (!order) throw new Error("Order not found");

      const isAdmin = user.role === "admin";
      const isBuyer =
        order.buyerId === user.id ||
        order.buyerEmail.toLowerCase() === user.email.toLowerCase();
      const isSeller = order.sellerId === user.id;
      // Admin can act as dummy sellers
      const seller = data.users.find((u) => u.id === order.sellerId);
      const adminAsSeller = isAdmin && seller?.dummy;

      let allowed = false;
      if (isAdmin && ADMIN_ACTIONS.includes(status)) allowed = true;
      if (isBuyer && BUYER_ACTIONS.includes(status)) allowed = true;
      if ((isSeller || adminAsSeller) && SELLER_ACTIONS.includes(status)) allowed = true;
      // Buyer guest confirm payment simulation: admin marks funds_held
      if (isBuyer && status === "funds_held") allowed = false;

      if (!allowed) throw new Error("You cannot set this status.");

      const labels: Partial<Record<DealStatus, string>> = {
        funds_held: "Payment confirmed. Funds are now held in escrow.",
        credentials_shared:
          "Seller shared account credentials. Private handle is now visible in this deal room.",
        completed: "Buyer confirmed delivery. Funds released to seller. Deal completed.",
        disputed: "Dispute opened. Admin escrow moderator will review.",
        cancelled: "Deal cancelled by admin.",
        refunded: "Buyer refunded. Escrow closed.",
      };

      setDealStatus(
        order,
        status,
        note || labels[status] || `Status updated to ${DEAL_STATUS_LABEL[status]}.`
      );

      if (status === "credentials_shared") {
        const listing = data.listings.find((l) => l.id === order.listingId);
        if (listing) {
          order.handleRevealed = true;
          addSystemMessage(
            order,
            `Private account handle/URL revealed: ${listing.privateHandle}`
          );
        }
      }
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Update failed" },
      { status: 400 }
    );
  }

  const store = await readStore();
  return NextResponse.json({ order: store.orders.find((o) => o.id === Number(id)) });
}
