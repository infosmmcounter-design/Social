import { NextResponse } from "next/server";
import { updateStore, nextId, readStore } from "@/lib/db";
import { getCurrentUser, requireUser } from "@/lib/auth";

export async function GET() {
  const store = await readStore();
  return NextResponse.json({ reviews: store.reviews });
}

export async function POST(req: Request) {
  const body = await req.json();
  const orderId = Number(body.orderId);
  const stars = Number(body.stars);
  const text = String(body.text || "").trim();
  const user = await getCurrentUser();

  if (!orderId || !stars || !text)
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });

  try {
    await updateStore((data) => {
      const order = data.orders.find((o) => o.id === orderId);
      if (!order || order.status !== "completed")
        throw new Error("Only completed deals can be reviewed");
      if (data.reviews.some((r) => r.orderId === orderId))
        throw new Error("Already reviewed");
      const email = user?.email || order.buyerEmail;
      if (order.buyerEmail.toLowerCase() !== email.toLowerCase() && user?.role !== "admin")
        throw new Error("Forbidden");
      data.reviews.push({
        id: nextId(data),
        orderId,
        listingId: order.listingId,
        sellerId: order.sellerId,
        stars,
        text,
        who: email.slice(0, 2) + "***",
        date: new Date().toISOString().slice(0, 10),
      });
      const seller = data.users.find((u) => u.id === order.sellerId);
      if (seller) {
        const revs = data.reviews.filter((r) => r.sellerId === seller.id);
        seller.reviewCount = revs.length;
        seller.rating = revs.reduce((a, r) => a + r.stars, 0) / revs.length;
      }
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Failed" },
      { status: 400 }
    );
  }
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request) {
  const auth = await requireUser(["admin"]);
  if (auth.error) return NextResponse.json({ error: auth.error }, { status: auth.status });
  const body = await req.json();
  await updateStore((data) => {
    data.reviews = data.reviews.filter((r) => r.id !== Number(body.id));
  });
  return NextResponse.json({ ok: true });
}
