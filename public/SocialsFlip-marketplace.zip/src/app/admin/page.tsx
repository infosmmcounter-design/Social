"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import { api } from "@/lib/api";
import { money } from "@/lib/constants";
import {
  CATEGORIES,
  DEAL_STATUS_LABEL,
  type CryptoWallet,
  type DealStatus,
} from "@/lib/types";

type Tab =
  | "dash"
  | "apps"
  | "sellers"
  | "listings"
  | "orders"
  | "dummy"
  | "requests"
  | "blog"
  | "set";

export default function AdminPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("dash");
  const [apps, setApps] = useState<
    {
      id: number;
      name: string;
      email: string;
      phone: string;
      country: string;
      about: string;
      title: string;
      cat: string;
      price: number;
      status: string;
    }[]
  >([]);
  const [sellers, setSellers] = useState<
    {
      id: number;
      name: string;
      country: string;
      verified: boolean;
      dummy: boolean;
      official: boolean;
      rating: number;
      reviewCount: number;
      listingCount: number;
      joinedAt: string;
    }[]
  >([]);
  const [listings, setListings] = useState<
    {
      id: number;
      title: string;
      cat: string;
      price: number;
      status: string;
      listed: boolean;
      seller?: { name: string; official?: boolean } | null;
    }[]
  >([]);
  const [orders, setOrders] = useState<
    { id: number; title: string; total: number; status: DealStatus; fee: number }[]
  >([]);
  const [requests, setRequests] = useState<
    { id: number; listingId: number; buyerEmail: string; status: string }[]
  >([]);
  const [posts, setPosts] = useState<{ id: number; title: string }[]>([]);
  const [settings, setSettings] = useState<{
    fee: number;
    allowDirectPayToSeller: boolean;
    autoDetectCrypto: boolean;
    cryptoWallets: (CryptoWallet & { network?: string })[];
  } | null>(null);
  const [dummyForm, setDummyForm] = useState({
    count: 3,
    listingsPerSeller: 3,
    name: "",
    verified: true,
  });
  const [newListing, setNewListing] = useState({
    sellerId: "2",
    title: "",
    cat: "youtube",
    price: "",
    desc: "",
    privateHandle: "",
    niche: "",
    followers: "",
  });
  const [blog, setBlog] = useState({ title: "", body: "" });
  const [pw, setPw] = useState({ current: "", next: "" });
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) router.push("/auth/login");
  }, [user, loading, router]);

  async function refresh() {
    const [a, s, l, o, r, b, set] = await Promise.all([
      api<{ applications: typeof apps }>("/api/applications"),
      api<{ sellers: typeof sellers }>("/api/admin/sellers"),
      api<{ listings: typeof listings }>("/api/listings?admin=1"),
      api<{ orders: typeof orders }>("/api/orders?scope=admin"),
      api<{ requests: typeof requests }>("/api/private-requests"),
      api<{ posts: typeof posts }>("/api/blog"),
      api<{ settings: NonNullable<typeof settings> }>("/api/admin/settings"),
    ]);
    setApps(a.applications);
    setSellers(s.sellers);
    setListings(l.listings);
    setOrders(o.orders);
    setRequests(r.requests);
    setPosts(b.posts);
    setSettings(set.settings);
  }

  useEffect(() => {
    if (user?.role === "admin") refresh().catch(console.error);
  }, [user]);

  if (loading || !user) return <p className="sec mut">Loading admin…</p>;

  const held = orders.filter((o) =>
    ["awaiting_payment", "funds_held", "credentials_shared", "disputed"].includes(
      o.status
    )
  );
  const released = orders.filter((o) => o.status === "completed");

  const tabs: [Tab, string][] = [
    ["dash", "Dashboard"],
    ["apps", "Applications"],
    ["sellers", "Sellers"],
    ["listings", "Listings"],
    ["orders", "Orders"],
    ["dummy", "Dummy Data / Seller Generator"],
    ["requests", "Private Requests"],
    ["blog", "Blog"],
    ["set", "Settings"],
  ];

  return (
    <section className="sec">
      <div className="row" style={{ justifyContent: "space-between" }}>
        <h1 style={{ fontSize: "2rem", margin: 0 }}>Admin panel</h1>
        <Link className="l" href="/" style={{ color: "var(--a)", fontWeight: 600 }}>
          View storefront
        </Link>
      </div>
      <p className="sm mut">
        Escrow moderation, approvals, crypto wallets, and dummy seller tools.
      </p>
      <div className="tabs">
        {tabs.map(([k, n]) => (
          <button
            key={k}
            className={tab === k ? "on" : ""}
            onClick={() => setTab(k)}
          >
            {n}
          </button>
        ))}
      </div>
      {msg ? <p className="okmsg">{msg}</p> : null}

      {tab === "dash" && (
        <div className="grid">
          <div className="card f">
            <div className="mut sm">Active escrow volume</div>
            <div className="price">
              {money(held.reduce((a, o) => a + o.total, 0))}
            </div>
          </div>
          <div className="card f">
            <div className="mut sm">Fee revenue (completed)</div>
            <div className="price">
              {money(released.reduce((a, o) => a + (o.fee || 0), 0))}
            </div>
          </div>
          <div className="card f">
            <div className="mut sm">New applications</div>
            <div className="price">{apps.filter((a) => a.status === "new").length}</div>
          </div>
          <div className="card f">
            <div className="mut sm">Live listings</div>
            <div className="price">
              {listings.filter((l) => l.listed).length}
            </div>
          </div>
        </div>
      )}

      {tab === "apps" && (
        <div className="tbl">
          <table>
            <thead>
              <tr>
                <th>Applicant</th>
                <th>Service</th>
                <th>Status</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {apps.map((a) => (
                <tr key={a.id}>
                  <td>
                    {a.name}
                    <br />
                    <span className="mut sm">
                      {a.email} · {a.phone} · {a.country}
                    </span>
                    <br />
                    <span className="sm">{a.about}</span>
                  </td>
                  <td>
                    {a.title}
                    <br />
                    <span className="mut sm">
                      {a.cat} · {money(a.price)}
                    </span>
                  </td>
                  <td>
                    <span
                      className={`pill ${
                        a.status === "new" ? "w" : a.status === "approved" ? "g" : "b"
                      }`}
                    >
                      {a.status}
                    </span>
                  </td>
                  <td>
                    {a.status === "new" ? (
                      <>
                        <button
                          className="btn s"
                          onClick={async () => {
                            const r = await api<{ tempPassword?: string }>(
                              "/api/applications",
                              { method: "PATCH", json: { id: a.id, approve: true } }
                            );
                            setMsg(
                              r.tempPassword
                                ? `Approved. Temp password: ${r.tempPassword}`
                                : "Approved"
                            );
                            refresh();
                          }}
                        >
                          Approve
                        </button>{" "}
                        <button
                          className="btn s o"
                          onClick={async () => {
                            await api("/api/applications", {
                              method: "PATCH",
                              json: { id: a.id, approve: false },
                            });
                            refresh();
                          }}
                        >
                          Reject
                        </button>
                      </>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!apps.length ? <p className="mut">No applications yet.</p> : null}
          <p className="sm mut">
            Approving creates seller access at your discretion. Storefront “Apply
            to sell” only submits the form.
          </p>
        </div>
      )}

      {tab === "sellers" && (
        <div className="tbl">
          <table>
            <thead>
              <tr>
                <th>Seller</th>
                <th>Country</th>
                <th>Listings</th>
                <th>Rating</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {sellers.map((s) => (
                <tr key={s.id}>
                  <td>
                    {s.name}{" "}
                    {s.official ? <span className="pill g">Our store</span> : null}{" "}
                    {s.dummy ? <span className="pill w">Dummy</span> : null}{" "}
                    {s.verified ? <span className="pill g">Verified</span> : null}
                    <br />
                    <span className="mut sm">
                      Joined {new Date(s.joinedAt).toLocaleDateString()}
                    </span>
                  </td>
                  <td>{s.country}</td>
                  <td>{s.listingCount}</td>
                  <td>
                    {s.official
                      ? "—"
                      : `${s.rating.toFixed(1)} (${s.reviewCount})`}
                  </td>
                  <td>
                    {!s.official ? (
                      <button
                        className="btn s o"
                        onClick={async () => {
                          if (!confirm("Remove seller and listings?")) return;
                          await api("/api/admin/sellers", {
                            method: "DELETE",
                            json: { id: s.id },
                          });
                          refresh();
                        }}
                      >
                        Remove
                      </button>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "listings" && (
        <>
          <div className="card">
            <h3>Add a listing</h3>
            <label>Listed under</label>
            <select
              value={newListing.sellerId}
              onChange={(e) =>
                setNewListing({ ...newListing, sellerId: e.target.value })
              }
            >
              {sellers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.official ? "SocialsFlip (our store)" : s.name}
                  {s.dummy ? " (dummy)" : ""}
                </option>
              ))}
            </select>
            <label>Category</label>
            <select
              value={newListing.cat}
              onChange={(e) => setNewListing({ ...newListing, cat: e.target.value })}
            >
              {CATEGORIES.map(([k, n]) => (
                <option key={k} value={k}>
                  {n}
                </option>
              ))}
            </select>
            <label>Title</label>
            <input
              value={newListing.title}
              onChange={(e) =>
                setNewListing({ ...newListing, title: e.target.value })
              }
            />
            <label>Private handle</label>
            <input
              value={newListing.privateHandle}
              onChange={(e) =>
                setNewListing({ ...newListing, privateHandle: e.target.value })
              }
            />
            <label>Price</label>
            <input
              type="number"
              value={newListing.price}
              onChange={(e) =>
                setNewListing({ ...newListing, price: e.target.value })
              }
            />
            <label>Description</label>
            <textarea
              rows={3}
              value={newListing.desc}
              onChange={(e) =>
                setNewListing({ ...newListing, desc: e.target.value })
              }
            />
            <button
              className="btn"
              onClick={async () => {
                await api("/api/listings", {
                  method: "POST",
                  json: {
                    ...newListing,
                    sellerId: Number(newListing.sellerId),
                    price: Number(newListing.price),
                    listed: true,
                  },
                });
                setMsg("Listing published");
                refresh();
              }}
            >
              Publish now
            </button>
          </div>
          <h3 style={{ marginTop: 22 }}>All listings</h3>
          <div className="tbl">
            <table>
              <thead>
                <tr>
                  <th>Listing</th>
                  <th>Owner</th>
                  <th>Price</th>
                  <th>Status</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {listings.map((l) => (
                  <tr key={l.id}>
                    <td>{l.title}</td>
                    <td>
                      {l.seller?.official ? (
                        <span className="pill g">SocialsFlip</span>
                      ) : (
                        l.seller?.name
                      )}
                    </td>
                    <td>{money(l.price)}</td>
                    <td>
                      <span className={`pill ${l.listed ? "g" : "w"}`}>
                        {l.status}
                        {l.listed ? " · live" : ""}
                      </span>
                    </td>
                    <td>
                      {l.status === "pending" ? (
                        <button
                          className="btn s"
                          onClick={async () => {
                            await api("/api/admin/listings", {
                              method: "PATCH",
                              json: { id: l.id, action: "approve" },
                            });
                            refresh();
                          }}
                        >
                          Approve
                        </button>
                      ) : (
                        <button
                          className="btn s o"
                          onClick={async () => {
                            await api("/api/admin/listings", {
                              method: "PATCH",
                              json: {
                                id: l.id,
                                action: l.listed ? "unlist" : "publish",
                              },
                            });
                            refresh();
                          }}
                        >
                          {l.listed ? "Unlist" : "Publish"}
                        </button>
                      )}{" "}
                      <button
                        className="btn s o"
                        onClick={async () => {
                          await api("/api/admin/listings", {
                            method: "PATCH",
                            json: { id: l.id, action: "delete" },
                          });
                          refresh();
                        }}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === "orders" && (
        <div className="tbl">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Item</th>
                <th>Total</th>
                <th>Status</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id}>
                  <td>{o.id}</td>
                  <td>{o.title}</td>
                  <td>{money(o.total)}</td>
                  <td>
                    <span
                      className={`pill ${
                        o.status === "disputed"
                          ? "b"
                          : o.status === "completed"
                            ? "g"
                            : "w"
                      }`}
                    >
                      {DEAL_STATUS_LABEL[o.status]}
                    </span>
                  </td>
                  <td>
                    <Link className="btn s o" href={`/deal/${o.id}`}>
                      Open chat / moderate
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!orders.length ? <p className="mut">No orders yet.</p> : null}
        </div>
      )}

      {tab === "dummy" && (
        <div className="card" style={{ maxWidth: 520 }}>
          <h3>Dummy Data / Seller Generator</h3>
          <p className="sm mut">
            Create unlimited realistic dummy sellers. When a real buyer starts a
            deal with them, you can reply as seller from the deal chat.
          </p>
          <label>How many sellers?</label>
          <input
            type="number"
            min={1}
            max={50}
            value={dummyForm.count}
            onChange={(e) =>
              setDummyForm({ ...dummyForm, count: Number(e.target.value) })
            }
          />
          <label>Listings per seller</label>
          <input
            type="number"
            min={1}
            max={10}
            value={dummyForm.listingsPerSeller}
            onChange={(e) =>
              setDummyForm({
                ...dummyForm,
                listingsPerSeller: Number(e.target.value),
              })
            }
          />
          <label>Custom name (optional, for 1 seller)</label>
          <input
            value={dummyForm.name}
            onChange={(e) => setDummyForm({ ...dummyForm, name: e.target.value })}
          />
          <label>
            <input
              type="checkbox"
              checked={dummyForm.verified}
              onChange={(e) =>
                setDummyForm({ ...dummyForm, verified: e.target.checked })
              }
              style={{ width: "auto", marginRight: 8 }}
            />
            Verified badge
          </label>
          <div className="row" style={{ marginTop: 12 }}>
            <button
              className="btn"
              onClick={async () => {
                const r = await api<{ created: unknown[] }>("/api/admin/dummy", {
                  method: "POST",
                  json: { ...dummyForm, autoListings: true },
                });
                setMsg(`${r.created.length} dummy seller(s) created with listings.`);
                refresh();
              }}
            >
              Generate sellers + listings
            </button>
            <button
              className="btn o"
              onClick={async () => {
                if (!confirm("Remove ALL dummy sellers?")) return;
                await api("/api/admin/dummy", { method: "DELETE", json: {} });
                setMsg("All dummy sellers removed");
                refresh();
              }}
            >
              Clear all dummies
            </button>
          </div>
          <p className="sm mut" style={{ marginTop: 12 }}>
            Current dummy sellers: {sellers.filter((s) => s.dummy).length}
          </p>
        </div>
      )}

      {tab === "requests" && (
        <div className="tbl">
          <table>
            <thead>
              <tr>
                <th>Buyer</th>
                <th>Listing</th>
                <th>Status</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {requests.map((r) => (
                <tr key={r.id}>
                  <td>{r.buyerEmail}</td>
                  <td>#{r.listingId}</td>
                  <td>{r.status}</td>
                  <td>
                    {r.status === "requested" ? (
                      <>
                        <button
                          className="btn s"
                          onClick={async () => {
                            await api("/api/private-requests", {
                              method: "PATCH",
                              json: { id: r.id, approve: true },
                            });
                            refresh();
                          }}
                        >
                          Approve reveal
                        </button>{" "}
                        <button
                          className="btn s o"
                          onClick={async () => {
                            await api("/api/private-requests", {
                              method: "PATCH",
                              json: { id: r.id, approve: false },
                            });
                            refresh();
                          }}
                        >
                          Deny
                        </button>
                      </>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "blog" && (
        <>
          <div className="card">
            <label>Post title</label>
            <input
              value={blog.title}
              onChange={(e) => setBlog({ ...blog, title: e.target.value })}
            />
            <label>Body</label>
            <textarea
              rows={4}
              value={blog.body}
              onChange={(e) => setBlog({ ...blog, body: e.target.value })}
            />
            <button
              className="btn"
              onClick={async () => {
                await api("/api/blog", { method: "POST", json: blog });
                setBlog({ title: "", body: "" });
                refresh();
              }}
            >
              Publish post
            </button>
          </div>
          <div className="tbl" style={{ marginTop: 14 }}>
            <table>
              <tbody>
                {posts.map((p) => (
                  <tr key={p.id}>
                    <td>{p.title}</td>
                    <td>
                      <button
                        className="btn s o"
                        onClick={async () => {
                          await api("/api/blog", {
                            method: "DELETE",
                            json: { id: p.id },
                          });
                          refresh();
                        }}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === "set" && settings && (
        <div className="card" style={{ maxWidth: 560 }}>
          <h3>Escrow & crypto settings</h3>
          <p className="sm mut">
            Payments are crypto-only: USDT TRC20 (Tron) and USDT BEP20 (BNB Smart
            Chain). No JazzCash / bank / local methods.
          </p>
          <label>Escrow fee on seller listings (%)</label>
          <input
            type="number"
            min={0}
            max={30}
            value={settings.fee}
            onChange={(e) =>
              setSettings({ ...settings, fee: Number(e.target.value) })
            }
          />
          <div className="note sm">
            <b>Trust Wallet tip:</b> App ko Trust Wallet se “link” nahi karte.
            Trust Wallet mein USDT deposit addresses copy karke yahan paste
            karein. Buyer wahan send karega; aap Trust Wallet / Tronscan /
            BscScan se check karke deal chat mein “Confirm payment” dabayein.
            Auto-confirm ke liye baad mein TronGrid + BscScan API keys chahiye
            hongi — Trust Wallet khud website ko webhook nahi bhejta.
          </div>
          <label>
            <input
              type="checkbox"
              checked={settings.autoDetectCrypto}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  autoDetectCrypto: e.target.checked,
                })
              }
              style={{ width: "auto", marginRight: 8 }}
            />
            Auto-detect crypto (placeholder — needs explorer API keys later)
          </label>
          <h3 style={{ marginTop: 18 }}>Escrow USDT addresses</h3>
          {settings.cryptoWallets.map((w, i) => (
            <div key={w.asset} style={{ marginBottom: 10 }}>
              <label>
                <input
                  type="checkbox"
                  checked={w.enabled}
                  onChange={(e) => {
                    const cryptoWallets = [...settings.cryptoWallets];
                    cryptoWallets[i] = { ...w, enabled: e.target.checked };
                    setSettings({ ...settings, cryptoWallets });
                  }}
                  style={{ width: "auto", marginRight: 8 }}
                />
                {w.label} {w.network ? `· ${w.network}` : ""}
              </label>
              <input
                placeholder={
                  w.asset === "USDT_TRC20"
                    ? "T… Tron address from Trust Wallet"
                    : "0x… BNB Smart Chain address from Trust Wallet"
                }
                value={w.address}
                onChange={(e) => {
                  const cryptoWallets = [...settings.cryptoWallets];
                  cryptoWallets[i] = { ...w, address: e.target.value.trim() };
                  setSettings({ ...settings, cryptoWallets });
                }}
              />
            </div>
          ))}
          <button
            className="btn"
            onClick={async () => {
              await api("/api/admin/settings", {
                method: "POST",
                json: { ...settings, allowDirectPayToSeller: false },
              });
              setMsg("Crypto settings saved");
            }}
          >
            Save settings
          </button>

          <h3 style={{ marginTop: 28 }}>Change admin password</h3>
          <p className="sm mut">
            Live pe pehle default <code>admin123</code> change kar dein.
          </p>
          <label>Current password</label>
          <input
            type="password"
            value={pw.current}
            onChange={(e) => setPw({ ...pw, current: e.target.value })}
          />
          <label>New password</label>
          <input
            type="password"
            value={pw.next}
            onChange={(e) => setPw({ ...pw, next: e.target.value })}
          />
          <button
            className="btn o"
            style={{ marginTop: 10 }}
            onClick={async () => {
              await api("/api/admin/password", {
                method: "POST",
                json: pw,
              });
              setPw({ current: "", next: "" });
              setMsg("Admin password updated");
            }}
          >
            Update password
          </button>
        </div>
      )}
    </section>
  );
}
