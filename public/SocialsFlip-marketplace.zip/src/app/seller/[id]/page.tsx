"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { ListingCard } from "@/components/ListingCard";
import { api } from "@/lib/api";
import { stars } from "@/lib/constants";

export default function SellerProfilePage() {
  const { id } = useParams<{ id: string }>();
  const [data, setData] = useState<{
    seller: {
      id: number;
      name: string;
      country: string;
      bio: string;
      verified: boolean;
      official: boolean;
      rating: number;
      reviewCount: number;
      joinedAt: string;
      dummy: boolean;
    };
    listings: {
      id: number;
      title: string;
      cat: string;
      price: number;
      followers?: string;
      monetized?: boolean;
    }[];
    reviews: { stars: number; who: string; date: string; text: string }[];
  } | null>(null);

  useEffect(() => {
    api<typeof data extends null ? never : NonNullable<typeof data>>(
      `/api/sellers/${id}`
    )
      .then(setData)
      .catch(() => setData(null));
  }, [id]);

  if (!data) return <p className="sec mut">Loading seller…</p>;
  const s = data.seller;

  return (
    <section className="sec">
      <h1 style={{ fontSize: "2rem" }}>{s.name}</h1>
      <div className="row">
        {s.official ? <span className="pill g">Official store</span> : null}
        {s.verified ? <span className="pill g">Verified</span> : null}
        {s.dummy ? <span className="pill w">Demo seller</span> : null}
        <span className="mut sm">
          Joined {new Date(s.joinedAt).toLocaleDateString()} · {s.country}
        </span>
      </div>
      <p>{s.bio}</p>
      <p className="sm">
        {s.reviewCount ? (
          <>
            <span className="star">{stars(s.rating)}</span> {s.rating.toFixed(1)} (
            {s.reviewCount})
          </>
        ) : (
          <span className="mut">No reviews yet</span>
        )}
      </p>
      <h2 style={{ marginTop: 24 }}>Listings</h2>
      <div className="grid">
        {data.listings.map((l) => (
          <ListingCard key={l.id} listing={{ ...l, seller: s }} />
        ))}
        {!data.listings.length ? <p className="mut">No live listings.</p> : null}
      </div>
    </section>
  );
}
