"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { api } from "@/lib/api";
import { money } from "@/lib/constants";
import { DEAL_FLOW, DEAL_STATUS_LABEL, type DealStatus } from "@/lib/types";
import { useAuth } from "@/components/AuthProvider";

type Msg = { id: number; from: string; text: string; createdAt: string };
type Wallet = { asset: string; address: string; label: string; network?: string };
type Order = {
  id: number;
  title: string;
  status: DealStatus;
  total: number;
  price: number;
  fee: number;
  buyerEmail: string;
  buyerName: string;
  coin: string;
  paymentMode: string;
  paymentInstructions: string;
  paymentProof: string;
  handleRevealed: boolean;
  privateHandle: string | null;
  msgs: Msg[];
  sellerId: number;
  buyerId: number | null;
  det: string;
};

function DealInner() {
  const { id } = useParams<{ id: string }>();
  const sp = useSearchParams();
  const emailQ = sp.get("email") || "";
  const { user } = useAuth();
  const [order, setOrder] = useState<Order | null>(null);
  const [seller, setSeller] = useState<{ name: string; dummy?: boolean } | null>(
    null
  );
  const [wallets, setWallets] = useState<Wallet[]>([]);
  const [text, setText] = useState("");
  const [txHash, setTxHash] = useState("");
  const [asRole, setAsRole] = useState<"admin" | "seller">("admin");
  const [err, setErr] = useState("");
  const [copied, setCopied] = useState("");
  const [stars, setStars] = useState(5);
  const [review, setReview] = useState("");

  const load = useCallback(async () => {
    const params = new URLSearchParams({ id: String(id) });
    if (emailQ) params.set("email", emailQ);
    const d = await api<{
      order: Order;
      seller: { name: string; dummy?: boolean } | null;
      wallets?: Wallet[];
    }>(`/api/orders?${params}`);
    setOrder(d.order);
    setSeller(d.seller);
    setWallets(d.wallets || []);
  }, [id, emailQ]);

  useEffect(() => {
    load().catch((e) => setErr(e.message));
    const t = setInterval(() => load().catch(() => {}), 5000);
    return () => clearInterval(t);
  }, [load]);

  if (err && !order) return <p className="sec err">{err}</p>;
  if (!order) return <p className="sec mut">Loading deal room…</p>;

  const isAdmin = user?.role === "admin";
  const isBuyer =
    (user &&
      (user.id === order.buyerId ||
        user.email.toLowerCase() === order.buyerEmail.toLowerCase())) ||
    (!!emailQ && emailQ.toLowerCase() === order.buyerEmail.toLowerCase());
  const isSeller = user && user.id === order.sellerId;
  const adminAsDummy = isAdmin && seller?.dummy;
  const flowIdx = DEAL_FLOW.indexOf(order.status);

  const payWallet =
    wallets.find((w) =>
      order.coin.toUpperCase().includes("BEP")
        ? w.asset === "USDT_BEP20"
        : w.asset === "USDT_TRC20"
    ) || wallets[0];

  async function copyAddr() {
    if (!payWallet?.address) return;
    await navigator.clipboard.writeText(payWallet.address);
    setCopied(payWallet.address);
    setTimeout(() => setCopied(""), 2000);
  }

  async function send() {
    if (!text.trim()) return;
    await api(`/api/orders/${order!.id}/messages`, {
      method: "POST",
      json: {
        text,
        email: emailQ || user?.email,
        asRole: isAdmin ? asRole : undefined,
      },
    });
    setText("");
    await load();
  }

  async function setStatus(status: DealStatus, note?: string) {
    await api(`/api/orders/${order!.id}/status`, {
      method: "POST",
      json: { status, note },
    });
    await load();
  }

  async function submitProof() {
    if (!txHash.trim()) return;
    await api(`/api/orders/${order!.id}/proof`, {
      method: "POST",
      json: { txHash, email: emailQ || user?.email },
    });
    setTxHash("");
    await load();
  }

  async function postReview() {
    await api("/api/reviews", {
      method: "POST",
      json: { orderId: order!.id, stars, text: review },
    });
    alert("Review posted");
    setReview("");
  }

  const roleLabel: Record<string, string> = {
    buyer: "Buyer",
    seller: "Seller",
    admin: "Admin (Escrow)",
  };

  return (
    <section className="sec" style={{ maxWidth: 720 }}>
      <Link className="mut sm" href="/orders">
        Back to orders
      </Link>
      <h1 style={{ fontSize: "1.7rem", marginTop: 8 }}>
        Escrow Deal #{order.id}
      </h1>
      <p className="mut">
        {order.title} · {money(order.total)}
        {order.fee ? ` (${money(order.price)} + ${money(order.fee)} fee)` : ""}
      </p>
      <div className="row">
        <span
          className={`pill ${
            order.status === "disputed" || order.status === "cancelled"
              ? "b"
              : order.status === "completed"
                ? "g"
                : "w"
          }`}
        >
          {DEAL_STATUS_LABEL[order.status]}
        </span>
        <span className="pill bl">Escrow crypto · {order.coin}</span>
        <span className="pill">3-way chat</span>
      </div>

      {order.status !== "disputed" &&
      order.status !== "cancelled" &&
      order.status !== "refunded" ? (
        <div className="steps">
          {DEAL_FLOW.map((f, j) => (
            <span key={f} className={j <= flowIdx || order.status === f ? "on" : ""}>
              {DEAL_STATUS_LABEL[f]}
            </span>
          ))}
        </div>
      ) : null}

      <div className="card f" style={{ marginTop: 12 }}>
        <h3 style={{ marginTop: 0 }}>Pay escrow ({order.coin})</h3>
        <p className="sm mut" style={{ margin: "0 0 8px" }}>
          Send exactly <b>{money(order.total)}</b> as USDT on the selected
          network only.
        </p>
        {payWallet?.address ? (
          <div className="row" style={{ flexWrap: "nowrap" }}>
            <input readOnly value={payWallet.address} />
            <button className="btn s" type="button" onClick={copyAddr}>
              {copied ? "Copied" : "Copy"}
            </button>
          </div>
        ) : (
          <p className="err">Escrow wallet not configured yet.</p>
        )}
        <p className="sm mut" style={{ marginTop: 8 }}>
          {order.paymentInstructions}
        </p>
        {order.paymentProof ? (
          <p className="okmsg">Proof submitted: {order.paymentProof}</p>
        ) : null}
        {isBuyer && order.status === "awaiting_payment" ? (
          <div style={{ marginTop: 10 }}>
            <label>TX hash / payment proof</label>
            <div className="row" style={{ flexWrap: "nowrap" }}>
              <input
                value={txHash}
                onChange={(e) => setTxHash(e.target.value)}
                placeholder="Paste transaction hash after sending USDT"
              />
              <button className="btn s" type="button" onClick={submitProof}>
                Submit
              </button>
            </div>
          </div>
        ) : null}
      </div>

      <div className="note sm">
        <b>Buyer:</b> {order.buyerName} ({order.buyerEmail}) · <b>Seller:</b>{" "}
        {seller?.name}
        {seller?.dummy ? " (dummy — admin can reply)" : ""}
        <br />
        <b>Transfer notes:</b> {order.det}
        {order.handleRevealed && order.privateHandle ? (
          <>
            <br />
            <b>Private handle:</b> {order.privateHandle}
          </>
        ) : (
          <>
            <br />
            <b>Private handle:</b> Hidden until credentials stage
          </>
        )}
      </div>

      <div className="row" style={{ marginBottom: 12 }}>
        {isAdmin ? (
          <>
            <button
              className="btn s"
              disabled={order.status !== "awaiting_payment"}
              onClick={() => setStatus("funds_held")}
            >
              Confirm payment / Hold funds
            </button>
            <button className="btn s g" onClick={() => setStatus("completed")}>
              Release funds / Complete
            </button>
            <button className="btn s d" onClick={() => setStatus("disputed")}>
              Mark disputed
            </button>
            <button className="btn s o" onClick={() => setStatus("cancelled")}>
              Cancel deal
            </button>
            <button className="btn s o" onClick={() => setStatus("refunded")}>
              Refund buyer
            </button>
          </>
        ) : null}
        {(isSeller || adminAsDummy) && (
          <button
            className="btn s"
            disabled={!["funds_held", "awaiting_payment"].includes(order.status)}
            onClick={() => setStatus("credentials_shared")}
          >
            Share credentials
          </button>
        )}
        {isBuyer && (
          <>
            <button
              className="btn s"
              disabled={
                !["credentials_shared", "funds_held"].includes(order.status)
              }
              onClick={() => setStatus("completed")}
            >
              Confirm I received it
            </button>
            <button
              className="btn s d"
              disabled={
                ![
                  "awaiting_payment",
                  "funds_held",
                  "credentials_shared",
                ].includes(order.status)
              }
              onClick={() => setStatus("disputed")}
            >
              Open dispute
            </button>
          </>
        )}
      </div>

      <h2>Deal chat</h2>
      <div className="chat" role="log">
        {order.msgs.map((m) => (
          <div key={m.id} className={`m ${m.from}`}>
            <small>
              {roleLabel[m.from] || m.from} ·{" "}
              {new Date(m.createdAt).toLocaleString()}
            </small>
            {m.text}
          </div>
        ))}
      </div>
      <div className="row" style={{ marginTop: 8, flexWrap: "nowrap" }}>
        {isAdmin ? (
          <select
            value={asRole}
            onChange={(e) => setAsRole(e.target.value as "admin" | "seller")}
            style={{ width: "auto" }}
          >
            <option value="admin">As Admin</option>
            <option value="seller">As Seller (dummy/support)</option>
          </select>
        ) : null}
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Message to buyer, seller and escrow"
          aria-label="Message"
          onKeyDown={(e) => {
            if (e.key === "Enter") send();
          }}
        />
        <button className="btn" onClick={send}>
          Send
        </button>
      </div>

      {order.status === "completed" && isBuyer ? (
        <div className="card f" style={{ marginTop: 16 }}>
          <h3>Review this purchase</h3>
          <label>Rating</label>
          <select
            value={stars}
            onChange={(e) => setStars(Number(e.target.value))}
          >
            {[5, 4, 3, 2, 1].map((n) => (
              <option key={n} value={n}>
                {n} stars
              </option>
            ))}
          </select>
          <label>Your review</label>
          <textarea
            rows={3}
            value={review}
            onChange={(e) => setReview(e.target.value)}
          />
          <div style={{ marginTop: 10 }}>
            <button className="btn" onClick={postReview}>
              Post review
            </button>
          </div>
        </div>
      ) : null}
    </section>
  );
}

export default function DealPage() {
  return (
    <Suspense fallback={<p className="sec mut">Loading…</p>}>
      <DealInner />
    </Suspense>
  );
}
