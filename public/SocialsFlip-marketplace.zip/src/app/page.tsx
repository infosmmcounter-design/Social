"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ListingCard } from "@/components/ListingCard";
import { CatIcon } from "@/components/Icons";
import { api } from "@/lib/api";
import { CATEGORIES } from "@/lib/types";

type Listing = {
  id: number;
  title: string;
  cat: string;
  price: number;
  img?: string;
  followers?: string;
  monetized?: boolean;
  seller?: {
    name: string;
    country?: string;
    official?: boolean;
    verified?: boolean;
    rating?: number;
    reviewCount?: number;
  } | null;
};

export default function HomePage() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [q, setQ] = useState("");
  const router = useRouter();

  useEffect(() => {
    api<{ listings: Listing[] }>("/api/listings")
      .then((d) => setListings(d.listings))
      .catch(() => setListings([]));
  }, []);

  const counts = Object.fromEntries(
    CATEGORIES.map(([k]) => [k, listings.filter((l) => l.cat === k).length])
  );

  return (
    <>
      <section className="hero">
        <span className="tag">Escrow-held payments on marketplace orders</span>
        <h1>
          A marketplace where you can buy social media accounts, services and
          tools.
        </h1>
        <div className="sbox">
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#56627a"
            strokeWidth="2"
            strokeLinecap="round"
          >
            <circle cx="11" cy="11" r="7" />
            <path d="M16.5 16.5L21 21" />
          </svg>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search by service title"
            aria-label="Search"
            onKeyDown={(e) => {
              if (e.key === "Enter")
                router.push(`/listings?q=${encodeURIComponent(q.trim())}`);
            }}
          />
          <button
            className="btn"
            onClick={() =>
              router.push(`/listings?q=${encodeURIComponent(q.trim())}`)
            }
          >
            Search
          </button>
        </div>
      </section>

      <section className="sec" style={{ paddingBottom: 6 }}>
        <h2>Browse by platform</h2>
        <div className="tiles">
          {CATEGORIES.map(([k, name]) => (
            <Link key={k} className="tile" href={`/listings?cat=${k}`}>
              <div className="ic">
                <CatIcon cat={k} size={40} />
                {counts[k] ? <span className="bd">{counts[k]}</span> : null}
              </div>
              {name}
            </Link>
          ))}
        </div>
      </section>

      <section className="sec">
        <div className="row" style={{ justifyContent: "space-between" }}>
          <h2 style={{ margin: 0 }}>Latest listings</h2>
          <Link href="/listings" style={{ color: "var(--a)", fontWeight: 700 }}>
            See all
          </Link>
        </div>
        <div className="grid" style={{ marginTop: 14 }}>
          {listings.slice(0, 6).map((l) => (
            <ListingCard key={l.id} listing={l} />
          ))}
          {!listings.length ? (
            <p className="mut">No listings yet. Check back soon.</p>
          ) : null}
        </div>
      </section>
    </>
  );
}
