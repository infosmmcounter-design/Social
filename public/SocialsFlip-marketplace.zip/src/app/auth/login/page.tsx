"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import { useAuth, type AuthUser } from "@/components/AuthProvider";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const { setUser } = useAuth();
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    try {
      const d = await api<{ user: AuthUser }>("/api/auth/login", {
        method: "POST",
        json: { email, password },
      });
      setUser(d.user);
      if (d.user.role === "admin") router.push("/admin");
      else if (d.user.role === "seller") router.push("/dashboard/seller");
      else router.push("/dashboard/buyer");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Login failed");
    }
  }

  return (
    <section className="sec" style={{ maxWidth: 420 }}>
      <h1 style={{ fontSize: "2rem" }}>Log in</h1>
      <p className="mut sm">
        Demo: admin@socialsflip.com / admin123 · buyer@demo.com / buyer123
      </p>
      <form className="card" onSubmit={submit}>
        <label>Email</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <label>Password</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        {err ? <p className="err">{err}</p> : null}
        <div style={{ marginTop: 14 }}>
          <button className="btn" type="submit">
            Log in
          </button>
        </div>
      </form>
      <p className="sm mut" style={{ marginTop: 12 }}>
        New here? <Link href="/auth/signup">Create a buyer account</Link>. Guests
        can also checkout without signing up.
      </p>
    </section>
  );
}
