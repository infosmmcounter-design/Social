import Link from "next/link";
import { CatIcon } from "./Icons";
import { money, stars } from "@/lib/constants";
import { CATEGORIES } from "@/lib/types";

type Props = {
  listing: {
    id: number;
    title: string;
    cat: string;
    price: number;
    img?: string;
    monetized?: boolean;
    followers?: string;
    seller?: {
      name: string;
      country?: string;
      official?: boolean;
      verified?: boolean;
      rating?: number;
      reviewCount?: number;
    } | null;
  };
};

export function ListingCard({ listing }: Props) {
  const catName =
    CATEGORIES.find((c) => c[0] === listing.cat)?.[1] || listing.cat;
  const s = listing.seller;
  return (
    <Link className="card lc" href={`/listing/${listing.id}`}>
      <div className="im">
        {listing.img ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={listing.img} alt="" />
        ) : (
          <CatIcon cat={listing.cat} size={56} />
        )}
      </div>
      <div className="bd2">
        <span className="pill" style={{ display: "inline-flex", gap: 5, alignItems: "center" }}>
          <CatIcon cat={listing.cat} size={14} />
          {catName}
        </span>{" "}
        {s?.official ? <span className="pill g">Sold by SocialsFlip</span> : null}
        {s?.verified && !s.official ? <span className="pill g">Verified</span> : null}
        <h3 style={{ marginTop: 8 }}>{listing.title}</h3>
        <p className="sm mut" style={{ margin: "0 0 4px" }}>
          {s?.official ? "SocialsFlip" : s?.name || "Seller"}
          {s?.country ? `, ${s.country}` : ""}
        </p>
        {listing.followers ? (
          <p className="sm mut" style={{ margin: "0 0 4px" }}>
            {listing.followers} · {listing.monetized ? "Monetized" : "Not monetized"}
          </p>
        ) : null}
        <p className="sm" style={{ margin: "0 0 6px" }}>
          {s?.reviewCount ? (
            <>
              <span className="star">{stars(s.rating || 0)}</span>{" "}
              {(s.rating || 0).toFixed(1)} ({s.reviewCount})
            </>
          ) : (
            <span className="mut">No reviews yet</span>
          )}
        </p>
        <div className="price">{money(listing.price)}</div>
      </div>
    </Link>
  );
}
