SocialsFlip Marketplace

npm install && npm run dev
Admin /admin password admin123
Netlify: npx netlify deploy --prod --build
