# SocialsFlip Marketplace

Escrow-protected marketplace for social media accounts (USDT TRC20 / BEP20 only).

## Live on phone (GitHub + Vercel)

See step-by-step guide: **[docs/DEPLOY-MOBILE.md](docs/DEPLOY-MOBILE.md)**

You need:
1. Merge PR to `main`
2. Free Neon Postgres → `DATABASE_URL`
3. Import repo in Vercel → add `DATABASE_URL` → Deploy

## Local

```bash
npm install
npm run dev
```

Open http://localhost:3000

### Demo logins

| Role  | Email                 | Password |
|-------|-----------------------|----------|
| Admin | admin@socialsflip.com | admin123 |
| Buyer | buyer@demo.com        | buyer123 |

## Escrow wallets

- USDT TRC20: `TLj1Esv4stWJNcimvXZDXkP5W9FZfQVpx7`
- USDT BEP20: `0x97ff787aa462141bc27660BFDB8b96728B3e0209`

## Stack

- Next.js App Router + API routes
- Local file store (dev) / Neon Postgres via `DATABASE_URL` (Vercel)
- Supabase-ready SQL: `supabase/schema.sql`
