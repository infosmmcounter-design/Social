import { NextResponse } from "next/server";
import { readStore, publicUser } from "@/lib/db";

/** Public seller directory (no dummy badge). */
export async function GET() {
  const store = await readStore();
  const sellers = store.users
    .filter((u) => u.active && (u.role === "seller" || u.official))
    .map((u) => {
      const live = store.listings.filter(
        (l) => l.sellerId === u.id && l.listed && l.status === "approved"
      ).length;
      return {
        ...publicUser(u),
        listingCount: live,
      };
    })
    .filter((s) => s.listingCount > 0 || s.official)
    .sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount);

  return NextResponse.json({ sellers });
}
