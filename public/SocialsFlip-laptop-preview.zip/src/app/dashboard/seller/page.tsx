"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import { api } from "@/lib/api";
import { money } from "@/lib/constants";
import { CATEGORIES, DEAL_STATUS_LABEL, type DealStatus } from "@/lib/types";

export default function SellerDashboard() {
  const { user, loading, refresh: refreshAuth } = useAuth();
  const router = useRouter();
  const [listings, setListings] = useState<
    {
      id: number;
      title: string;
      price: number;
      status: string;
      listed: boolean;
      cat: string;
      stock?: number;
    }[]
  >([]);
  const [orders, setOrders] = useState<
    { id: number; title: string; total: number; status: DealStatus }[]
  >([]);
  const [requests, setRequests] = useState<
    { id: number; listingId: number; buyerEmail: string; status: string }[]
  >([]);
  const [chats, setChats] = useState<
    {
      id: number;
      subject: string;
      buyerName: string;
      buyerEmail: string;
      sellerName: string;
      updatedAt: string;
    }[]
  >([]);
  const [form, setForm] = useState({
    title: "",
    cat: "youtube",
    niche: "",
    followers: "",
    monetized: false,
    teaser: "",
    privateHandle: "",
    price: "",
    desc: "",
    stock: "1",
    listingType: "account",
    img: "",
  });
  const [profile, setProfile] = useState({
    name: "",
    bio: "",
    country: "",
    phone: "",
    avatarUrl: "",
  });
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (!loading && (!user || (user.role !== "seller" && user.role !== "admin"))) {
      router.push("/auth/login");
    }
  }, [user, loading, router]);

  async function refresh() {
    const [l, o, r, me, ch] = await Promise.all([
      api<{ listings: typeof listings }>("/api/listings?mine=1"),
      api<{ orders: typeof orders }>("/api/orders?scope=seller"),
      api<{ requests: typeof requests }>("/api/private-requests"),
      api<{
        seller: {
          name: string;
          bio: string;
          country: string;
          phone?: string;
          avatarUrl?: string;
        };
      }>("/api/sellers/me"),
      api<{ inquiries: typeof chats }>("/api/inquiries?scope=seller"),
    ]);
    setListings(l.listings);
    setOrders(o.orders);
    setRequests(r.requests);
    setChats(ch.inquiries);
    setProfile({
      name: me.seller.name || "",
      bio: me.seller.bio || "",
      country: me.seller.country || "",
      phone: me.seller.phone || "",
      avatarUrl: me.seller.avatarUrl || "",
    });
  }

  useEffect(() => {
    if (user) refresh().catch(() => {});
  }, [user]);

  function readImageFile(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!file.type.startsWith("image/")) {
        reject(new Error("Please choose an image file."));
        return;
      }
      if (file.size > 1_200_000) {
        reject(new Error("Image must be under ~1.2MB."));
        return;
      }
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = () => reject(new Error("Could not read image."));
      reader.readAsDataURL(file);
    });
  }

  async function createListing(e: React.FormEvent) {
    e.preventDefault();
    setMsg("");
    try {
      await api("/api/listings", {
        method: "POST",
        json: {
          ...form,
          price: Number(form.price),
          stock: Number(form.stock) || 1,
        },
      });
      setMsg("Listing submitted for admin approval.");
      setForm({
        title: "",
        cat: "youtube",
        niche: "",
        followers: "",
        monetized: false,
        teaser: "",
        privateHandle: "",
        price: "",
        desc: "",
        stock: "1",
        listingType: "account",
        img: "",
      });
      await refresh();
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Failed");
    }
  }

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    setMsg("");
    try {
      await api("/api/sellers/me", { method: "PATCH", json: profile });
      await refreshAuth();
      setMsg("Profile updated — public page refreshed.");
    } catch (err) {
      setMsg(err instanceof Error ? err.message : "Failed");
    }
  }

  if (loading || !user) return <p className="sec mut">Loading…</p>;

  return (
    <section className="sec">
      <h1 style={{ fontSize: "2rem" }}>Seller dashboard</h1>
      <p className="mut">
        Manage profile, listings, private requests, and deals.{" "}
        {user.id ? (
          <Link href={`/seller/${user.id}`} style={{ color: "var(--a)", fontWeight: 600 }}>
            View public profile
          </Link>
        ) : null}
      </p>
      {msg ? <p className="okmsg">{msg}</p> : null}

      <h2>Your public profile</h2>
      <form className="card" onSubmit={saveProfile}>
        <div className="row" style={{ gap: 14, alignItems: "center" }}>
          {profile.avatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={profile.avatarUrl}
              alt=""
              style={{ width: 64, height: 64, borderRadius: "50%", objectFit: "cover" }}
            />
          ) : null}
          <div style={{ flex: 1 }}>
            <label>Profile photo</label>
            <input
              type="file"
              accept="image/*"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                try {
                  const dataUrl = await readImageFile(f);
                  setProfile({ ...profile, avatarUrl: dataUrl });
                } catch (err) {
                  setMsg(err instanceof Error ? err.message : "Upload failed");
                }
              }}
            />
          </div>
        </div>
        <label>Display name</label>
        <input
          value={profile.name}
          onChange={(e) => setProfile({ ...profile, name: e.target.value })}
          required
        />
        <label>Country</label>
        <input
          value={profile.country}
          onChange={(e) => setProfile({ ...profile, country: e.target.value })}
        />
        <label>Phone (private)</label>
        <input
          value={profile.phone}
          onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
        />
        <label>Bio</label>
        <textarea
          rows={3}
          value={profile.bio}
          onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
        />
        <button className="btn" type="submit">
          Save profile
        </button>
      </form>

      <h2 style={{ marginTop: 24 }}>Post a listing</h2>
      <form className="card" onSubmit={createListing}>
        <label>Title</label>
        <input
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          required
        />
        <label>Platform</label>
        <select
          value={form.cat}
          onChange={(e) => setForm({ ...form, cat: e.target.value })}
        >
          {CATEGORIES.map(([k, n]) => (
            <option key={k} value={k}>
              {n}
            </option>
          ))}
        </select>
        <label>Niche</label>
        <input
          value={form.niche}
          onChange={(e) => setForm({ ...form, niche: e.target.value })}
        />
        <label>Followers / subscribers</label>
        <input
          value={form.followers}
          onChange={(e) => setForm({ ...form, followers: e.target.value })}
        />
        <label>
          <input
            type="checkbox"
            checked={form.monetized}
            onChange={(e) => setForm({ ...form, monetized: e.target.checked })}
            style={{ width: "auto", marginRight: 8 }}
          />
          Monetized
        </label>
        <label>Teaser description</label>
        <textarea
          rows={2}
          value={form.teaser}
          onChange={(e) => setForm({ ...form, teaser: e.target.value })}
        />
        <label>Private handle / URL (hidden publicly)</label>
        <input
          value={form.privateHandle}
          onChange={(e) => setForm({ ...form, privateHandle: e.target.value })}
          required
        />
        <label>Type</label>
        <select
          value={form.listingType}
          onChange={(e) => setForm({ ...form, listingType: e.target.value })}
        >
          <option value="account">Account</option>
          <option value="service">Service</option>
          <option value="tool">Tool</option>
        </select>
        <label>Available stock (how many identical units you can sell)</label>
        <input
          type="number"
          min={0}
          value={form.stock}
          onChange={(e) => setForm({ ...form, stock: e.target.value })}
        />
        <p className="sm mut">
          Example: you list “1K monetized YouTube channel” but have 5 similar
          channels ready — set stock to 5. Each sale reduces stock by 1.
        </p>
        <label>Cover image (upload or leave blank for auto)</label>
        <input
          type="file"
          accept="image/*"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            try {
              const dataUrl = await readImageFile(f);
              setForm({ ...form, img: dataUrl });
            } catch (err) {
              setMsg(err instanceof Error ? err.message : "Upload failed");
            }
          }}
        />
        {form.img ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={form.img}
            alt=""
            style={{
              marginTop: 8,
              width: "100%",
              maxHeight: 160,
              objectFit: "cover",
              borderRadius: 8,
            }}
          />
        ) : null}
        <label>Price (USD)</label>
        <input
          type="number"
          value={form.price}
          onChange={(e) => setForm({ ...form, price: e.target.value })}
          required
        />
        <label>Full description</label>
        <textarea
          rows={3}
          value={form.desc}
          onChange={(e) => setForm({ ...form, desc: e.target.value })}
        />
        <button className="btn" type="submit">
          Submit for approval
        </button>
      </form>

      <p className="note sm">
        Payments are crypto-only (USDT TRC20 / BEP20) into SocialsFlip escrow.
        Buyers do not pay you via local methods.
      </p>

      <h2 style={{ marginTop: 24 }}>Your listings</h2>
      <div className="tbl">
        <table>
          <thead>
            <tr>
              <th>Title</th>
              <th>Price</th>
              <th>Available stock</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {listings.map((l) => (
              <tr key={l.id}>
                <td>
                  <Link href={`/listing/${l.id}`}>{l.title}</Link>
                </td>
                <td>{money(l.price)}</td>
                <td>
                  <input
                    type="number"
                    min={0}
                    defaultValue={l.stock ?? 1}
                    style={{ width: 72 }}
                    aria-label={`Stock for ${l.title}`}
                    onBlur={async (e) => {
                      const stock = Number(e.target.value);
                      if (!Number.isFinite(stock) || stock < 0) return;
                      try {
                        await api("/api/listings", {
                          method: "PATCH",
                          json: { id: l.id, stock },
                        });
                        setMsg(`Stock updated: ${l.title} → ${stock}`);
                        await refresh();
                      } catch (err) {
                        setMsg(
                          err instanceof Error ? err.message : "Stock update failed"
                        );
                      }
                    }}
                  />
                </td>
                <td>
                  <span className={`pill ${l.listed ? "g" : "w"}`}>
                    {l.status}
                    {l.listed ? " · live" : ""}
                    {(l.stock ?? 1) <= 0 ? " · sold out" : ""}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h2 style={{ marginTop: 24 }}>Private detail requests</h2>
      <div className="tbl">
        <table>
          <thead>
            <tr>
              <th>Buyer</th>
              <th>Listing</th>
              <th>Status</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {requests.map((r) => (
              <tr key={r.id}>
                <td>{r.buyerEmail}</td>
                <td>#{r.listingId}</td>
                <td>{r.status}</td>
                <td>
                  {r.status === "requested" ? (
                    <>
                      <button
                        className="btn s"
                        onClick={async () => {
                          await api("/api/private-requests", {
                            method: "PATCH",
                            json: { id: r.id, approve: true },
                          });
                          refresh();
                        }}
                      >
                        Approve
                      </button>{" "}
                      <button
                        className="btn s o"
                        onClick={async () => {
                          await api("/api/private-requests", {
                            method: "PATCH",
                            json: { id: r.id, approve: false },
                          });
                          refresh();
                        }}
                      >
                        Deny
                      </button>
                    </>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!requests.length ? <p className="mut">No requests.</p> : null}
      </div>

      <h2 style={{ marginTop: 24 }}>Buyer chats (before deal)</h2>
      <div className="tbl">
        <table>
          <thead>
            <tr>
              <th>Buyer</th>
              <th>Topic</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {chats.map((c) => (
              <tr key={c.id}>
                <td>
                  {c.buyerName}
                  <br />
                  <span className="mut sm">{c.buyerEmail}</span>
                </td>
                <td>{c.subject}</td>
                <td>
                  <Link className="btn s" href={`/chat/${c.id}`}>
                    Reply as {c.sellerName || profile.name || "you"}
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!chats.length ? (
          <p className="mut">No pre-deal chats yet.</p>
        ) : null}
      </div>

      <h2 style={{ marginTop: 24 }}>Deals</h2>
      <div className="tbl">
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Item</th>
              <th>Status</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id}>
                <td>{o.id}</td>
                <td>{o.title}</td>
                <td>{DEAL_STATUS_LABEL[o.status]}</td>
                <td>
                  <Link className="btn s o" href={`/deal/${o.id}`}>
                    Chat
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
