"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ListingCard } from "@/components/ListingCard";
import { BrandLogo } from "@/components/BrandLogo";
import { CatIcon } from "@/components/Icons";
import { VerifiedTick } from "@/components/VerifiedTick";
import { api } from "@/lib/api";
import { stars } from "@/lib/constants";
import { CATEGORIES } from "@/lib/types";

type Listing = {
  id: number;
  title: string;
  cat: string;
  price: number;
  img?: string;
  followers?: string;
  monetized?: boolean;
  stock?: number;
  soldOut?: boolean;
  seller?: {
    id?: number;
    name: string;
    country?: string;
    official?: boolean;
    verified?: boolean;
    rating?: number;
    reviewCount?: number;
    avatarUrl?: string;
  } | null;
};

type Seller = {
  id: number;
  name: string;
  country: string;
  bio: string;
  verified: boolean;
  official: boolean;
  rating: number;
  reviewCount: number;
  avatarUrl: string;
  listingCount: number;
};

type SortKey = "newest" | "price_asc" | "price_desc";
type ViewMode = "listings" | "sellers";

export default function HomePage() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [sellers, setSellers] = useState<Seller[]>([]);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("");
  const [sort, setSort] = useState<SortKey>("newest");
  const [view, setView] = useState<ViewMode>("listings");

  useEffect(() => {
    api<{ listings: Listing[] }>("/api/listings")
      .then((d) => setListings(d.listings))
      .catch(() => setListings([]));
    api<{ sellers: Seller[] }>("/api/sellers")
      .then((d) => setSellers(d.sellers))
      .catch(() => setSellers([]));
  }, []);

  const counts = Object.fromEntries(
    CATEGORIES.map(([k]) => [k, listings.filter((l) => l.cat === k).length])
  );

  const filtered = useMemo(() => {
    let list = listings;
    if (cat) list = list.filter((l) => l.cat === cat);
    if (q.trim()) {
      const qq = q.trim().toLowerCase();
      list = list.filter((l) =>
        [l.title, l.cat, l.seller?.name || ""].join(" ").toLowerCase().includes(qq)
      );
    }
    if (sort === "price_asc") list = [...list].sort((a, b) => a.price - b.price);
    else if (sort === "price_desc") list = [...list].sort((a, b) => b.price - a.price);
    else list = [...list].sort((a, b) => b.id - a.id);
    return list;
  }, [listings, cat, q, sort]);

  return (
    <>
      <section className="hero hero-home">
        <div className="hero-inner">
          <BrandLogo size={48} />
          <p className="hero-kicker">Escrow-protected marketplace</p>
          <h1>Buy social accounts, services &amp; tools with confidence.</h1>
          <p className="hero-sub">
            Pay USDT (TRC20 / BEP20) into escrow. Chat with seller and admin until
            delivery is confirmed.
          </p>
          <div className="sbox">
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#56627a"
              strokeWidth="2"
              strokeLinecap="round"
              aria-hidden
            >
              <circle cx="11" cy="11" r="7" />
              <path d="M16.5 16.5L21 21" />
            </svg>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search listings on this page"
              aria-label="Search"
            />
            <button className="btn" type="button" onClick={() => setView("listings")}>
              Search
            </button>
          </div>
        </div>
      </section>

      <section className="sec" style={{ paddingBottom: 6 }}>
        <div className="row" style={{ justifyContent: "space-between", gap: 12 }}>
          <h2 style={{ margin: 0 }}>Browse</h2>
          <div className="view-toggle">
            <button
              type="button"
              className={view === "listings" ? "on" : ""}
              onClick={() => setView("listings")}
            >
              Listings
            </button>
            <button
              type="button"
              className={view === "sellers" ? "on" : ""}
              onClick={() => setView("sellers")}
            >
              Sellers
            </button>
          </div>
        </div>

        {view === "listings" ? (
          <>
            <div className="filter-bar">
              <button
                type="button"
                className={`chip ${!cat ? "on" : ""}`}
                onClick={() => setCat("")}
              >
                All
              </button>
              {CATEGORIES.map(([k, name]) => (
                <button
                  key={k}
                  type="button"
                  className={`chip ${cat === k ? "on" : ""}`}
                  onClick={() => setCat(cat === k ? "" : k)}
                >
                  <CatIcon cat={k} size={16} />
                  {name}
                  {counts[k] ? <span className="chip-n">{counts[k]}</span> : null}
                </button>
              ))}
              <select
                className="sort-select"
                value={sort}
                onChange={(e) => setSort(e.target.value as SortKey)}
                aria-label="Sort by price"
              >
                <option value="newest">Newest</option>
                <option value="price_asc">Price: low → high</option>
                <option value="price_desc">Price: high → low</option>
              </select>
            </div>

            <div className="grid" style={{ marginTop: 14 }}>
              {filtered.map((l) => (
                <ListingCard key={l.id} listing={l} />
              ))}
              {!filtered.length ? (
                <p className="mut">No listings match this filter.</p>
              ) : null}
            </div>
          </>
        ) : (
          <div className="seller-grid" id="sellers" style={{ marginTop: 14 }}>
            {sellers.map((s) => (
              <Link key={s.id} className="seller-tile" href={`/seller/${s.id}`}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img className="seller-av" src={s.avatarUrl} alt="" />
                <div>
                  <strong>
                    {s.name}
                    {s.verified ? <VerifiedTick size={15} /> : null}
                  </strong>
                  <p className="sm mut" style={{ margin: "2px 0 0" }}>
                    {s.official ? "Official store" : s.country || "Seller"} ·{" "}
                    {s.listingCount} listing{s.listingCount === 1 ? "" : "s"}
                  </p>
                  <p className="sm" style={{ margin: "4px 0 0" }}>
                    {s.reviewCount ? (
                      <>
                        <span className="star">{stars(s.rating)}</span>{" "}
                        {s.rating.toFixed(1)} ({s.reviewCount})
                      </>
                    ) : (
                      <span className="mut">No reviews yet</span>
                    )}
                  </p>
                </div>
              </Link>
            ))}
            {!sellers.length ? <p className="mut">No sellers yet.</p> : null}
          </div>
        )}
      </section>
    </>
  );
}
