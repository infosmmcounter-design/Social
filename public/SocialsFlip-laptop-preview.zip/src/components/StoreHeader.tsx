"use client";

import Link from "next/link";
import { useAuth } from "./AuthProvider";
import { BrandLogo } from "./BrandLogo";

export function StoreHeader() {
  const { user, logout } = useAuth();
  const dash =
    user?.role === "admin"
      ? "/admin"
      : user?.role === "seller"
        ? "/dashboard/seller"
        : "/dashboard/buyer";

  return (
    <header className="sf-header">
      <div className="w">
        <nav className="sf-nav">
          <BrandLogo size={38} />
          <span className="sp" />
          <Link className="l" href="/listings">
            Listings
          </Link>
          <Link className="l" href="/#sellers">
            Sellers
          </Link>
          <Link className="l" href="/create-deal">
            Create deal
          </Link>
          <Link className="l" href="/apply">
            Sell
          </Link>
          <Link className="l" href="/chats">
            Chats
          </Link>
          <Link className="l" href="/orders">
            Orders
          </Link>
          <Link className="l" href="/blog">
            Blog
          </Link>
          {user ? (
            <>
              <Link className="l" href={dash}>
                {user.role === "admin" ? "Admin" : "Dashboard"}
              </Link>
              <button className="btn s o" onClick={() => logout()}>
                Log out
              </button>
            </>
          ) : (
            <Link className="btn s" href="/auth/login">
              Log in
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
